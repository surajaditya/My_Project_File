<?php
      include_once('include/database.php');

      if(isset($_POST['sub']))
      {
        //$p_sq_no=$_POST['p_sq_no'];
        $name=$_POST['title'];
        $mrp=$_POST['mrp'];
        $price=$_POST['price'];
        $offers=$_POST['offers'];
        $offerv=$_POST['offer_validation'];
        $productd=$_POST['product_des'];
        //$catalogue=$_POST['catalogue'];
        //$brand=$_POST['brand'];
        $stock=$_POST['stock'];
        $product_type=$_POST['pro_type'];


          $query="INSERT INTO details(title, mrp, price, offers, offer_validation, productdescription,  stock, product_type) VALUES('$name', '$mrp', '$price', '$offers', '$offerv', '$productd', '$stock', '$product_type')";
             
             $result=mysqli_query($con,$query);

         if($result=true)
         {
       


        for($i=0; $i<=count($_FILES['myfile']['name']); $i++)
        {
        $fname1=$_FILES['myfile']['name'][$i];
        $ftmp1=$_FILES['myfile']['tmp_name'][$i];
        $store1="images/product_image".$fname1;
        move_uploaded_file($ftmp1, $store1);

        $query="INSERT INTO images(img) VALUES ('$store1')";

         $result=mysqli_query($con,$query);

         if($query)
         {
          echo "<script>alert('Data Inserted')</script>";
         }
        else
        {
                echo "<script>alert('Faild..!')</script>";
        }
      }
    }
  }
       
?>

<?php include 'partials/header.php';?>
<div class="container-scroller">
<!-- partial:partials/_navbar.html -->
<?php include 'partials/navbar.php';?>
<!-- partial -->
<div class="container-fluid page-body-wrapper">
<!-- partial:partials/_sidebar.html -->
<?php include 'partials/sidebar.php';?>	  
<!-- partial -->
<div class="main-panel">
	<div class="content-wrapper">
<div class="col-md-8 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h2 class="card-title"><u>Product Detail Insert Form</u></h2>
                  <p class="card-description"></p>
				<form class="forms-sample" method="POST" enctype="multipart/form-data">
					<div class="form-group">
                      <label for="exampleInputName1">Product Sequence No.</label>
                      <input type="text" class="form-control" id="exampleInputName1" name="p_sq_no" readonly />
                    </div>
                    <div class="form-group">
                      <label for="exampleInputName1">Product Title</label>
                      <input type="text" class="form-control" id="exampleInputName1" name="title" placeholder="Product Name">
                    </div>
                    
                    <div class="form-group">
                      <label for="exampleInputCity1">Product Mrp</label>
                      <input type="text" class="form-control" id="exampleInputCity1" name="mrp" placeholder="Product Mrp">
                    </div>
					<div class="form-group">
                      <label for="exampleInputName1">Product Price</label>
                      <input type="text" class="form-control" id="exampleInputName1" name="price" placeholder="Product Price">
                    </div>
					<div class="form-group">
                      <label for="exampleInputName1">Offer</label>
                      <input type="text" class="form-control" id="exampleInputName1" name="offers" placeholder="Offer">
                    </div>
					<div class="form-group">
                      <label for="exampleInputName1">Offer Validation</label>
                      <input type="text" class="form-control" id="exampleInputName1" name="offer_validation" placeholder="Offer Validation">
                    </div>
					<div class="form-group">
                      <label for="exampleInputName1">Brand Name</label>
                      <select class="form-control" id="exampleInputName1" name ="brand" placeholder="brand">
						  <option class="form-control">Select Brand</option>
						  <?php 
								  include_once('include/database.php');
                              $query=("select * from brand");
                              $result=mysqli_query($con,$query);
                                while($row=mysqli_fetch_array($result))
                                {
                           ?>
							<option class="form-control" value="<?php echo $row['brand'] ?> "><?php echo $row['brand'] ?></option>
                            <?php } ?>                        
					  </select>
                    </div>
					
					<div class="form-group">
                      <label for="exampleInputName1">Stock</label>
                      <input type="text" class="form-control" id="exampleInputName1" name="stock" placeholder="Stock">
                    </div>
					<div class="form-group">
                      <label for="exampleInputName1">Product Type</label>
                      <select class="form-control" id="exampleInputName1" name="pro_type" placeholder="pro_type">
						  <option class="form-control">Select Type</option>
						  <?php 
								  include_once('include/database.php');
                              $query=("select * from pro_category");
                              $result=mysqli_query($con, $query);
                                while($row=mysqli_fetch_array($result))
                                {
                           ?>
							<option class="form-control" value="<?php echo $row['pro_category_name'] ?> "><?php echo $row['pro_category_name'] ?></option>
                            <?php } ?>                        
					  </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleTextarea1">Product Description</label>
                      <textarea class="form-control" id="exampleTextarea1" rows="2" name="product_des" ></textarea>
                    </div>
					<hr>
					<!--div class="form-group">
                      <label>File upload</label>
                      <input type="file" name="img[]" class="file-upload-default">
                      <div class="input-group col-xs-12">
                        <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
                        <span class="input-group-append">
						<input type="file" name="myfile[]" class="file-upload-default">
                          <button class="file-upload-browse btn btn-info" type="button">Upload</button>
                        </span>
                      </div>
                    </div-->

          <div class="form-group">
                      <label>File upload</label>
            <input type="file" name="myfile[]" multiple="multiple" />
                      </div>
                    <button type="submit" class="btn btn-success mr-2" name="sub" >Submit</button>
                    <button class="btn btn-light">Cancel</button>
                 </form>
				 
	</div>
</div>
</div>
</div>
<!-- partial -->
</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
  <!-- container-scroller -->


<?php include 'partials/footer.php';?>
