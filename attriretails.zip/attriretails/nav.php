<header><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
		<!-- top Header -->
		<div id="top-header">
			<div class="container">
				<div class="pull-left">
					<ul class="footer-social">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-instagram"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
						</ul>
				</div>
				<div class="pull-right">
					<ul class="header-top-links passlogin">
						<li><a href="login.php">login</a></li>
						<li><a href="user_registration.php" class="registers"><i class="fa fa-user-o"></i> Register</a></li>
						<li class="dropdown default-dropdown">
							<div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
								My Account <i class="fa fa-caret-down"></i>
							</div>
							
							<ul class="custom-menu">
								<li><a href="#"><i class="fa fa-user-o"></i> My Account</a></li>
								<li><a href="#"><i class="fa fa-heart-o"></i> My Wishlist</a></li>
								<li><a href="#"><i class="fa fa-exchange"></i> Compare</a></li>
								<li><a href="checkout.php"><i class="fa fa-check"></i> Checkout</a></li>
								<li><a href="login.php"><i class="fa fa-unlock-alt"></i> Login</a></li>
								<li><a href="user_registration.php"><i class="fa fa-user-plus"></i> Create An Account</a></li>
							</ul>
						</li>
						<li class="dropdown default-dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">ENG <i class="fa fa-caret-down"></i></a>
							<ul class="custom-menu">
								<li><a href="#">English (ENG)</a></li>
								<li><a href="#">Russian (Ru)</a></li>
								<li><a href="#">French (FR)</a></li>
								<li><a href="#">Spanish (Es)</a></li>
							</ul>
						</li>
						
					</ul>
				</div>
			</div>
		</div>
		<!-- /top Header -->

		<!-- header -->
		<div id="header">
			<div class="container">
				<div class="pull-left">
					<!-- Logo -->
					<div class="header-logo">
						<a class="logo" href="#">
							<img src="./img/logo.png" alt="">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Search --><div id="navigation">
		<!-- container -->
		<div class="">
			<div id="responsive-nav">
				<!-- category nav -->
				
				<!-- /category nav -->

				<!-- menu nav -->
				<div class="menu-nav">
					<span class="menu-header">Menu <i class="fa fa-bars"></i></span>
					<ul class="menu-list">
						<li><a href="#">Home</a></li>
						
					<?php
include 'include/database.php';
$query=mysqli_query($con,"select * from category");
while($row=mysqli_fetch_array($query)){
     $name=$row['category_name'];
     $sub_image=$row['category_image'];
?>	
<li class="dropdown mega-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><?php echo $name; ?> <i class="fa fa-caret-down"></i></a>
							<div class="custom-menu">
								<div class="row">
								<div class="col-md-4">
								<ul class="list-links">
								<?php 
								include 'include/database.php';
								$q="SELECT * FROM `sub_category` WHERE c_name='$name'";
								$result=mysqli_query($con,$q);
								while($row1=mysqli_fetch_array($result)){
								$name1=$row1['s_name'];
								?>	<li><h3 class="list-links-title"><?php echo $name1; ?></h3></li>
								<?php 
								include 'include/database.php';            
								$q1="SELECT * FROM `subsub_category` WHERE s_name='$name1'";                     
								$result1=mysqli_query($con,$q1);
								while($row2=mysqli_fetch_array($result1)){
								$name2=$row2['ss_cat'];
								?>
								<li><a href="#"><?php echo $name2; ?></a></li>
								<?php } ?>
								<?php } ?>
								</ul>
								<hr class="hidden-md hidden-lg">
								</div>
								</div>
								<div class="row hidden-sm hidden-xs">
									<div class="col-md-12">
										<hr>
										<a class="banner banner-1" href="#">
											<img src="<?php echo $sub_image; ?>" alt="">
											<div class="banner-caption text-center">
												<h2 class="white-color">NEW COLLECTION</h2>
												<h3 class="white-color font-weak">HOT DEAL</h3>
											</div>
										</a>
									</div>
								</div>
							</div>
						</li>
<?php } ?>
						
						<li class="dropdown default-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Brand <i class="fa fa-caret-down"></i></a>
							<ul class="custom-menu">
							<?php 
								include 'include/database.php';
								$querys="select * from details where product_type='subsubcat'";
								$result=mysqli_query($con, $querys);
								while($rows=mysqli_fetch_array($result)){
							?>
							<li><a href="products.php"><?php echo $rows['product_type'];?></a></li>
							<?php } ?>	
							</ul>
						</li>
						
					</ul>
				</div>
				<!-- menu nav -->
			</div>
		</div>
		<!-- /container -->
	</div>
					
					<!-- /Search -->
				</div>
				<div class="pull-right">
				<div class="header-search">
						<form>
							<input class="input search-input" type="text" placeholder="Enter your keyword">
							<select class="input search-categories">
								<option value="0">All Categories</option>
								<?php 
									include 'include/database.php';
									$query="select * from prod_category";
									$result=mysqli_query($con,$query);
									while($row=mysqli_fetch_array($result)){
								?>
								<option value="<?php echo $row['pro_id'];?>"><?php echo $row['pro_category_name'];?></option>
								<?php } ?>
								</select>
							<button class="search-btn"><i class="fa fa-search"></i></button>
						</form>
					</div>
					<ul class="header-btns">
						<!-- Account -->
						
						<!-- /Account -->

						<!-- Cart -->
						<li class="header-cart dropdown default-dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
								<div class="header-btns-icon">
									<i class="fa fa-shopping-cart"></i>
									<span class="qty">3</span>
								</div>
								<div class="mainsizes"><strong class="text-uppercase">My Cart:</strong>
								<br>
								<span>35.20$</span></div>
							</a>
							<div class="custom-menu">
								<div id="shopping-cart">
									<div class="shopping-cart-list">
										<div class="product product-widget">
											<div class="product-thumb">
												<img src="./img/thumb-product01.jpg" alt="">
											</div>
											<div class="product-body">
												<h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
												<h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
											</div>
											<button class="cancel-btn"><i class="fa fa-trash"></i></button>
										</div>
										<div class="product product-widget">
											<div class="product-thumb">
												<img src="./img/thumb-product01.jpg" alt="">
											</div>
											<div class="product-body">
												<h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
												<h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
											</div>
											<button class="cancel-btn"><i class="fa fa-trash"></i></button>
										</div>
									</div>
									<div class="shopping-cart-btns">
										<button class="main-btn">View Cart</button>
										<button class="primary-btn">Checkout <i class="fa fa-arrow-circle-right"></i></button>
									</div>
								</div>
							</div>
						</li>
						<!-- /Cart -->

						<!-- Mobile nav toggle-->
						<li class="nav-toggle">
							<button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
						</li>
						<!-- / Mobile nav toggle -->
					</ul>
				</div>
			</div>
			<!-- header -->
		</div>
		<!-- container -->
	</header>