Simple Shopping Cart with PHP
============================
1. Import "mysql_import.sql" in your MySql PhpMyAdmin to create product table.
2. Change settings in "config.php" for database.
3. Navigate to index page of your shopping cart and enjoy.

@License : http://opensource.org/licenses/MIT
@Tutorial : http://www.sanwebe.com/2013/06/creating-simple-shopping-cart-with-php
