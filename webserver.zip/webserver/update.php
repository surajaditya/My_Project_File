<?php
     include ('config.php');

    $id =  $_GET['id'];
    $name = $_GET['name'];
    $age = $_GET['age'];
    $gender = $_GET['gender'];
    $mobile = $_GET['mobile'];
    if(!empty($name) || !empty($age) || !empty($gender) || !empty($mobile))
    {
    $sql = "UPDATE users SET name = '$name', age = '$age', gender = '$gender', mobile = '$mobile' WHERE id = $id";
    $query =$conn->query($sql);
    if($query){
    	$data = array("status"=> 1,"msg" => "Record Upadated Successfully");

    }
    else{
    	$data = array("status" => 1, "msg" =>"Failed to Updated the Record" );

    }
}
@mysqli_close();
header ('content-type: application/json');
echo json_encode($data);

?>