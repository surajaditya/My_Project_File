<?php 
 
 include('config.php');
  $name = $_GET['name'];
  $age = $_GET['age'];
  $gender = $_GET['gender'];
  $mobile = $_GET['mobile'];
 if (!empty($name) && !empty($age) && !empty($gender) && !empty($mobile)) {
  	$sql = "INSERT INTO users (name, age, gender, mobile) VALUES('$name', '$age', '$gender', '$mobile')";
  	$query = $con->query($sql);
  	 if ($query) {
  	 	 $data = array("status" => 1, "msg" => "Record Saved Successfully" );
  	 }
  	 else{
        $data = array("status" => 0, "msg" => "Failed to save the record");
  	 }
  }
    @mysql_close();
    header('content-type: application/json');
    echo json_encode($data); 
?>