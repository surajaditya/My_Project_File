<?php 

   include ('config.php');
   $id=$_GET['id'];
    if (!empty($id)) {
      $sql = "SELECT name, age, gender, mobile FROM users WHERE id = $id";
        $query=con->query($sql);
        if ($query->num_rows > 0 ){
        	while($row = $query->fetch_array()){
        		$name = $row['name']; 
        		$age = $row['age'];
        		$gender = $row['gender'];
        		$mobile = $row['mobile'];
        		$result[] = array("$id" => $id, "name" =>$name, "age" =>$age, "gender" =>$gender, "mobile" =>$mobile);
        	}
             $data  = array("status" => 1, "info" => $result );
        }
        else{
        	$data = array("status" => 0, "msg" => "Record Not Found!");
       
        }
    }
   	@mysql_close($con);
   	
  header('Content-type: application/json');
   echo json_encode($data);
?>