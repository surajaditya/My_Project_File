<?php
include ('config.php');

$id= $_GET['id'];
if (!empty($id)) {
	$sql ="DELETE FROM users WHERE id = $id";
	$query = $conn->query($sql);
	if ($query){
		$data = array("status" =>1,"msg" => "Record Deleted Successfully");
	} 
	else{
		$data = array("status" =>0,"msg" => "Failed to Deleted Record");

	}
}

@mysqli_close();
header ('content-type: application/json');
echo json_encode($data);

?>