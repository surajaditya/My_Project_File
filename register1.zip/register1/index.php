<!DOCTYPE html>
<html>
<head>
	<title>Suraj</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>

<body>
<a href="Login.php">Login</a>
<center>
<form action="index.php" method="post" enctype="multipart/form-data">
	<table>
	<tr>
	<td align="center" colspan="2"><strong><h2>Student Registration</h2></strong></td>
	</tr>
		<tr>
			<td><strong>Student Name:</strong></td>
			<td><input type="text" name="username" placeholder="Student Name" id="input" ></td>
		</tr>
		<tr>
			<td><strong>Student Email:</strong></td>
			<td><input type="email" name="useremail" placeholder="Student Email ID" id="input" required/></td>
		</tr>
		<tr>
			<td><strong>Password:</strong></td>
			<td><input type="password" name="userpass" placeholder="Password" id="input" required/></td>
		</tr>
		<tr>
			<td><strong>Mobile No:</strong></td>
			<td><input type="text" name="usermobile" placeholder="Mobile No" id="input"  required/></td>
		</tr>
		<tr>
			<td><strong>Image:</strong></td>
			<td><input type="file" name="image" id="inputs" required/></td>
		</tr>
		<tr>
			<td><strong>Resume:</strong></td>
			<td><input type="file" name="resume" id="inputs" required/></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" name="submit" value="Sign-Up" id="btn"/></td>
		</tr>
	</table>
</form>
</center>
</body>
</html>


<?php

include 'Conn.php';

if(isset($_POST['submit'])){
	$username = $_POST['username'];
	$useremail = $_POST['useremail'];
	$userpass = $_POST['userpass'];
	$usermobile = $_POST['usermobile'];

	$imagename = $_FILES['image']['name'];
	$imagetmp = $_FILES['image']['tmp_name'];
	$type = $_FILES['image']['type'];
	$size = $_FILES['image']['size'];
	
	$resumename = $_FILES['resume']['name'];
	$resumetmp = $_FILES['resume']['tmp_name']; 
	$type = $_FILES['resume']['type'];
	$size = $_FILES['resume']['size'];
	
	
	move_uploaded_file($imagetmp,"images/$imagename");
	move_uploaded_file($resumetmp,"resume/$resumename");
	
	$query = "insert into student(name, email, password, mobile, imagename, imagetmp, resumename, resumetmp) values('$username', '$useremail', '$userpass', '$usermobile','$imagename', '$imagetmp', '$resumename', '$resumetmp')";

	$query_run = mysqli_query($con,$query);
	
	if(mysqli_query($con, $query_run)>0)
	{
	 		echo "<center><b><font size = '5' color='red'>Don't Store In Data Plz Try Again.....?</font></b></center>";
	 		}
	 		else
			{
	 			
	 			echo "<center><b><font size = '5' color='lightblue'>Data Store In Sucssesfully.....?</font></b></center>";
	 		}

	}

?>