-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2018 at 11:27 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `insertingdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `imagename` varchar(50) NOT NULL,
  `imagetmp` longblob NOT NULL,
  `resumename` varchar(50) NOT NULL,
  `resumetmp` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `password`, `mobile`, `imagename`, `imagetmp`, `resumename`, `resumetmp`) VALUES
(40, 'Pinky', 'pinky@gmail.com', '123', '123', 'images (26).jpg', 0x433a78616d7070096d70706870453231352e746d70, 'Set D.docx', 0x433a78616d7070096d70706870453231362e746d70),
(42, 'Ruhan', 'ruhan@gmail.com', '1234', '1234567890', 'images (9).jpg', 0x433a78616d7070096d70706870434139342e746d70, 'Set D.docx', 0x433a78616d7070096d70706870434141352e746d70),
(43, 'Ru', 'ruby@gmail.com', '1234', '0987654321', '', '', '', ''),
(46, 'fgfhhuj', 'ui@gmail.com', '123', '123457890', 'imagesj.jpeg', 0x433a78616d7070096d70706870374442332e746d70, 'Priyanka Rana Resume.doc', 0x433a78616d7070096d70706870374442342e746d70);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
