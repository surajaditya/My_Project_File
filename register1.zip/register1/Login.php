<?php
session_start ();

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>

	<style type="text/css">
		body{
			background-color:#008B8B;
			
		}

		input{
			
			margin-top: 20px;
			border-radius: 8px;
			font-size: 25px;
			border-color:#FFFAF0;
			
		}
	</style>
</head>
<body>
<a href="Index.php">Register New User</a>
	

<center>
	<form method="post">
		<strong>Email.Id</strong>
		<input type="email" name="email" placeholder="Email ID" required/></input></br>
		<strong>Password</strong>
		<input type="password" name="pass" placeholder="Password" required/></br></br>
		<input type="submit" name="login" value="Login">
	</form>
</center>

</body>
</html>


<?php
include 'Conn.php';
if(isset($_POST['login']))
{
$email = $_SESSION['email']=$_POST['email'];
$pass = $_POST['pass'];

$query = "select * from student where email ='$email' AND password ='$pass'";

$query_run = mysqli_query($con,$query); 
	
		if(mysqli_num_rows($query_run)>0){
		
			echo "<script> window.open('Retrieve.php?logged=Logged In Scuccessfully....?','_self')</script>";
		}
		else{
			echo "<script> window.open('Login.php?errored=Invalid User Name OR Password....?','_self')</script>";
		}
	}

?>
