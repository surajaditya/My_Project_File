-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2018 at 12:58 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `diagnostic`
--

CREATE TABLE `diagnostic` (
  `id` int(10) NOT NULL,
  `category` varchar(255) NOT NULL,
  `centre` varchar(255) NOT NULL,
  `year` varchar(100) NOT NULL,
  `services` varchar(500) NOT NULL,
  `emergency` varchar(100) NOT NULL,
  `management` varchar(100) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `mobilenumber1` varchar(12) NOT NULL,
  `mobilenumber2` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `image` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `diagnostic`
--

INSERT INTO `diagnostic` (`id`, `category`, `centre`, `year`, `services`, `emergency`, `management`, `degree`, `address`, `state`, `district`, `area`, `phone_number`, `mobilenumber1`, `mobilenumber2`, `email`, `website`, `message`, `image`) VALUES
(47, 'Blood Bank', 'jivananmol', '2017', 'hvjvjh', 'Available 24x7', 'Government', 'mbbs', 'sdsdsdss', 'Delhi', 'Mayur Vihar', 'Chilla Village', '8979797', '797978878', '78787878', 'surajadi@gmail.com', 'cars24.com', 'mjhdsjkhjkdsh', 'images/global.jpg'),
(48, 'Blood Bank', 'jivananmol', '2017', 'hvjvjh', 'Available 24x7', 'Government', 'mbbs', 'sdsdsdss', 'Delhi', 'Mayur Vihar', 'Chilla Village', '8979797', '797978878', '78787878', 'surajadi@gmail.com', 'cars24.com', 'mjhdsjkhjkdsh', 'images/global.jpg'),
(49, 'Blood Bank', 'jivananmol', '2017', 'hvjvjh', 'Available 24x7', 'Government', 'mbbs', 'sdsdsdss', 'Delhi', 'Mayur Vihar', 'Chilla Village', '8979797', '797978878', '78787878', 'surajadi@gmail.com', 'cars24.com', 'mjhdsjkhjkdsh', 'images/global.jpg'),
(50, 'Blood Bank', 'jivananmol', '2017', 'hvjvjh', 'Available 24x7', 'Government', 'mbbs', 'njkhkjdskj', 'Panjab', 'ludiyana', 'Sardar Mohhala', '79879787', '8789787', '77987798', 'surajadi@gmail.com', 'cars24.com', 'nkjshddhsk', 'images/panda1.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diagnostic`
--
ALTER TABLE `diagnostic`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diagnostic`
--
ALTER TABLE `diagnostic`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
