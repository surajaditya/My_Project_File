
<?php 

include 'config.php';

$id = $_GET ['id'];

$query = "delete from diagnostic where id = '$id'";

if (mysqli_query ($con, $query )) 
{
	
	echo "Data Delete Successfully";
} 
else
{
	echo " Not Delete data";
}

 ?>