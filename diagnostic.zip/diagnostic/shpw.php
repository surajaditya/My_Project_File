
<html>
<head>
	<title>Show Page</title>
</head>
  
 <style>
td{
	podding:$px;
}
</style>	
<?php
include 'config.php';


$query="SELECT * from diagnostic";
$data=mysqli_query($con, $query);
$total=mysqli_num_rows($data);
if($total!=0)
{
	?>
	<body>
	<table border="1" >
	<h1 align="center">Diagnostic</h1>
	<tr>
 <td>Id</td>
 <td>Category</td>
 <td>Name Of Centre</td>
 <td>Establishment Year</td>
 <td>Services Available In Centre</td>
 <td>Emergency servies available</td>
 <td>Management</td>
 <td>Name Of Consultant Doctor With Degree</td>
 <td>Address</td>
 <td>State</td>
 <td>District</td>
 <td>Geographical Area</td>
 <td>Phone No</td>
 <td>MobileNo1</td>
 <td>MobileNo2</td>
 <td>Email.Id</td>
 <td>Website</td>
 <td>Write More About Centre</td>
 <td>Photo/Logo Of Centre</td>
 <td>ACTION</td>
 <td>ACTION</td>
	</tr>
 <?php
	while($result=mysqli_fetch_assoc($data))
	{
		$id=$result['id'];
		echo "<tr>
		
		<td>".$result['id']."</td>
		<td>".$result['category']."</td> 
		<td>".$result['centre']."</td>
		<td>".$result['year']."</td>
		<td>".$result['services']."</td>
		<td>".$result['emergency']."</td>
		<td>".$result['management']."</td>
		<td>".$result['address']."</td>
		<td>".$result['degree']."</td>
		<td>".$result['state']."</td>
		<td>".$result['district']."</td>		
		<td>".$result['area']."</td>
		<td>".$result['phone_number']."</td> 
		<td>".$result['mobilenumber1']."</td>
		<td>".$result['mobilenumber2']."</td>
		<td>".$result['email']."</td>
		<td>".$result['website']."</td>
		<td>".$result['message']."</td>
		<td>".$result['image']."</td>
		

		
		
		<td>"?> <a href="updatedc.php?id=<?php echo $id; ?>">UPDATE </a> <?php echo "</td>
		<td>"?><a href="deletedc.php?id=<?php echo $id; ?>">DELETE </a> <?php echo "</td> 
		 
		 
		</tr>";
	}
}else
{
	echo"Table has not record";
	
}
	
		?>
		
	</body>
	</html>