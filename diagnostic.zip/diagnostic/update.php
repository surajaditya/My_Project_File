<?php
include 'config.php';
$id = $_GET['id'];
$query="select * from diagnostic where id='$id'";
$data=mysqli_query($con, $query);
 
	while($result=mysqli_fetch_assoc($data))
	{
	
	$category=$result['category'];
	$centre=$result['centre'];
	$year=$result['year'];
	$services=$result['services'];
	$emergency=$result['emergency'];
	$management=$result['management'];
	$address=$result['address'];
	$state=$result['state'];
	$district=$result['district'];
	$area=$result['area'];
	$phone_number=$result['phone_number'];
	$mobilenumber1=$result['mobilenumber1'];
	$mobilenumber2=$result['mobilenumber2'];
	$email=$result['email'];
	$website=$result['website'];
	$message=$result['message'];
	$image=$result['image'];
	

		
?>
                         



<html>
<head>
	<title>Diagnostic Form</title>
  </head>
   <body bgcolor="#87CEFA">
   	<hr>
	<h2 align="center"> Add Diagnostic Centre in Directory </h2>
	<hr>
  <form action="showdc.php" method="POST" width="100%">
 
<table border="4" bordercolor="grey" align="center" width="40%" >
 
<!----- Category ---------------------------------------------------------->
<tr>
<td>Category</td>
 <td >
    <select name="category">
      <option>Nothing Selected</option>
      <option>Blood Bank</option>
      <option>Eye Bank</option>
      <option>Pathology Centre</option>
      <option>Radiodiagnosis Centre</option>
      <option>Research Laboratory</option>
  </select>
</td>
  
</tr>
 
<!----- name of centre ---------------------------------------------------------->
<tr>
<td>Name Of Centre </td>
<td><input type="text" name="centre" placeholder=" Name Of Centre" value="<?php  echo $centre ?>">
</td>
</tr>

<!--------- Establishment----------------------------------------------------->
<tr>
<td>Establishment Year </td>
<td><input type="year" name="year" placeholder=" Establishment Year" value="<?php  echo $year ?>">
</td>
</tr>

<!----- Services ---------------------------------------------------------->
<tr>
<td>Services Available In Centre </td>
<td><input type="text" name="services" placeholder="Services Available" value="<?php  echo $services ?>"></td>
</tr>

<!----- Emergency ---------------------------------------------------------->
<tr>
<td>Emergency Service availablity </td>
<td>
	<select name="emergency">
		<option>Nothing Selected</option>
		<option>Available 24x7</option>
		<option>Not Available</option>
	</select>
</td>
</tr>
 
<!----- Email Id ---------------------------------------------------------->
<tr>
<td>Management</td>
<td>
	<select name="management">
		<option>Nothing Selected</option>
		<option>Government</option>
		<option>Private</option>
		<option>Trust</option>
	</select>
</td>
</tr>
 
<!----- Doctor Consultant ---------------------------------------------------------->
<tr>
<td>Name Of Consultant Doctor With Degree</td>
<td><input type="text" name="degree" placeholder="Name Of Consultant Doctor" ></td>
</tr>
 
<!----- Address ---------------------------------------------------------->
<tr>
<td>Address With Opening Hours</td>
<td><textarea name="address" rows="2" cols="30" value="<?php  echo $address ?>"></textarea>
</td>
</tr>
 
<!----- State ---------------------------------------------------------->
<tr>
<td>State</td>
<td>
	<select name="state">
		<option>Nothing Selected</option>
		<option>Delhi</option>
		<option>Panjab</option>
	</select>
</td>
</tr>
 
<!----- District ---------------------------------------------------------->
<tr>
<td>District</td>
<td>
	<select name="district">
		<option>.....................</option>
		<option>Mayur Vihar</option>
		<option>ludiyana</option>
	</select>
</td>
</tr>
 
<!----- Geographical Area ---------------------------------------------------------->
<tr>
<td>Geographical Area</td>
<td>
	<select name="area">
		<option>.....................</option>
		<option>Chilla Village</option>
        <option>Sardar Mohhala</option>
	</select>
</td>
</tr>
 
<!----- Phone Number ---------------------------------------------------------->
<tr>
<td>Phone Number</td>
<td><input type="Number" name="phone_number" value="Number" placeholder="Phone Number" value="<?php  echo $phone_number ?>"></td>
</tr>
 
<!----- mobile No 1---------------------------------------------------------->
 
<tr>
<td>Mobile Number 1</td>
<td><input type="Number" name="mobilenumber1" value="Number" placeholder="Mobile  Number 1" value="<?php  echo $mobilenumber1 ?>"></td>
</tr>

<!----- Mobile Number 2 ---------------------------------------------------------->
<tr>
<td>Mobile Number 2</td>
<td><input type="Number" name="mobilenumber2" value="Number" placeholder="Mobile Number 2" value="<?php  echo $mobilenumber2 ?>"></td>
</tr>

<!----- Email Id---------------------------------------------------------->
<tr>
<td>Email Id</td>
<td><input type="email" name="email" placeholder="Email Id" value="<?php  echo $email ?>"></td>	
</tr>
 
<!----- Website---------------------------------------------------------->
<tr>
<td>Website</td>
<td><input type="text" name="website" placeholder="Website" value="<?php  echo $website ?>"></td>	
</tr>
 
 <!----- Message ---------------------------------------------------------->
<tr>
<td>Write More About Centre</td>
<td><textarea name="message" rows="3" cols="40" value="<?php  echo $message ?>"></textarea>
</td>
</tr>

<!----- Photo/Logo ---------------------------------------------------------->
<tr>
<td>Photo/Logo Of Centre</td>
<td><input type="file" name="image" placeholder="Photo/Logo Of Centre"></td>
</tr>
 
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" name="submit" value="Submit">
<input type="reset" name="reset" value="Reset">
</td>
</tr>
</table>
 
</form>
</body>
</html>

<?php
include 'config.php';

if(isset($_POST['submit'])){
	
    
	$category=$result['category'];
	$centre=$result['centre'];
	$year=$result['year'];
	$servies=$result['servies'];
	$emergency=$result['emergency'];
	$management=$result['management'];
	$address=$result['address'];
	$state=$result['state'];
	$district=$result['district'];
	$area=$result['area'];
	$phonenumber=$result['phonenumber'];
	$mobilenumber1=$result['mobilenumber1'];
	$mobilenumber2=$result['mobilenumber2'];
	$email=$result['email'];
	$website=$result['website'];
	$message=$result['message'];
	$imagename=$result['imagename'];
	


 
$sql = "UPDATE diagnostic SET category='$category', centre='$centre', year='$year', servies='$services', emergency='$emergency', management='$management', address='$address', state='$state', district=$'district', area='$area', phonenumber='$phonenumber', mobilenumber1='$moblienumber1', mobilenumber2='$mobilenumber2', email='$email', website='$website',message='$message',
imagename='$imagename', WHERE id='$id'";

if (mysqli_query($con,$sql)) {
	header('location:showdc.php');
} else {
    echo "ERROR: " . $sql . "<br>" . mysqli_error($con);
}

mysqli_close($con);

}
}

?>
