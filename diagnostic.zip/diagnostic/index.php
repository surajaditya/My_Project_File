<html>
<head>
	<title>Diagnostic Form</title>
  </head>
   <body bgcolor="#87CEFA">
   	<hr>
	<h2 align="center"> Add Diagnostic Centre in Directory </h2>
	<hr>
  <form action="" method="POST" width="100%" enctype="multipart/form-data">
 
<table border="4" bordercolor="grey" align="center" width="40%" >
 
<!----- Category ---------------------------------------------------------->
<tr>
<td>Category</td>
 <td >
    <select name="category">
      <option>Nothing Selected</option>
      <option>Blood Bank</option>
      <option>Eye Bank</option>
      <option>Pathology Centre</option>
      <option>Radiodiagnosis Centre</option>
      <option>Research Laboratory</option>
  </select>
</td>
  
</tr>
 
<!----- name of centre ---------------------------------------------------------->
<tr>
<td>Name Of Centre </td>
<td><input type="text" name="centre" placeholder=" Name Of Centre">
</td>
</tr>

<!--------- Establishment----------------------------------------------------->
<tr>
<td>Establishment Year </td>
<td><input type="year" name="year" placeholder=" Establishment Year">
</td>
</tr>

<!----- Services ---------------------------------------------------------->
<tr>
<td>Services Available In Centre </td>
<td><input type="text" name="services" placeholder="Services Available"></td>
</tr>

<!----- Emergency ---------------------------------------------------------->
<tr>
<td>Emergency Service availablity </td>
<td>
	<select name="emergency">
		<option>Nothing Selected</option>
		<option>Available 24x7</option>
		<option>Not Available</option>
	</select>
</td>
</tr>
 
<!----- Email Id ---------------------------------------------------------->
<tr>
<td>Management</td>
<td>
	<select name="management">
		<option>Nothing Selected</option>
		<option>Government</option>
		<option>Private</option>
		<option>Trust</option>
	</select>
</td>
</tr>
 
<!----- Doctor Consultant ---------------------------------------------------------->
<tr>
<td>Name Of Consultant Doctor With Degree</td>
<td>
<input type="text" name="degree" placeholder="Name Of Consultant Doctor" >
</td>
</tr>
 
<!----- Address ---------------------------------------------------------->
<tr>
<td>Address With Opening Hours</td>
<td><textarea name="address" rows="2" cols="30"></textarea>
</td>
</tr>
 
<!----- State ---------------------------------------------------------->
<tr>
<td>State</td>
<td>
	<select name="state">
		<option>Nothing Selected</option>
		<option>Delhi</option>
		<option>Panjab</option>
	</select>
</td>
</tr>
 
<!----- District ---------------------------------------------------------->
<tr>
<td>District</td>
<td>
	<select name="district">
		<option>.....................</option>
		<option>Mayur Vihar</option>
		<option>ludiyana</option>
	</select>
</td>
</tr>
 
<!----- Geographical Area ---------------------------------------------------------->
<tr>
<td>Geographical Area</td>
<td>
	<select name="area">
		<option>.....................</option>
		<option>Chilla Village</option>
        <option>Sardar Mohhala</option>
	</select>
</td>
</tr>
 
<!----- Phone Number ---------------------------------------------------------->
<tr>
<td>Phone Number</td>
<td><input type="Number" name="phone_number" value="Number" placeholder="Phone Number"></td>
</tr>
 
<!----- mobile No 1---------------------------------------------------------->
 
<tr>
<td>Mobile Number 1</td>
<td><input type="Number" name="mobilenumber1" value="Number" placeholder="Mobile  Number 1"></td>
</tr>

<!----- Mobile Number 2 ---------------------------------------------------------->
<tr>
<td>Mobile Number 2</td>
<td><input type="Number" name="mobilenumber2" value="Number" placeholder="Mobile Number 2"></td>
</tr>

<!----- Email Id---------------------------------------------------------->
<tr>
<td>Email Id</td>
<td><input type="email" name="email" placeholder="Email Id"></td>	
</tr>
 
<!----- Website---------------------------------------------------------->
<tr>
<td>Website</td>
<td><input type="text" name="website" placeholder="Website"></td>	
</tr>
 
 <!----- Message ---------------------------------------------------------->
<tr>
<td>Write More About Centre</td>
<td><textarea name="message" rows="3" cols="40"></textarea>
</td>
</tr>

<!----- Photo/Logo ---------------------------------------------------------->
<tr>
<td>Photo/Logo Of Centre</td>
<td><input type="file" name="image" /></td>
</tr>
 
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" name="submit" value="Submit">
<input type="reset" name="reset" value="Reset">
</td>
</tr>
</table>
 
</form>
</body>
</html>


<?php
  
  include('config.php');

if(isset($_POST['submit'])){
	$category = $_POST['category'];
	$centre = $_POST['centre'];
	$year = $_POST['year'];
	$services = $_POST['services'];
	$emergency = $_POST['emergency'];
	$management = $_POST['management'];
	$degree = $_POST['degree'];
	$address = $_POST['address'];
	$state = $_POST['state'];
	$district = $_POST['district'];
	$area = $_POST['area'];
	$phone_number = $_POST['phone_number'];
	$mobile_number1 = $_POST['mobilenumber1'];
	$mobile_number2 = $_POST['mobilenumber2'];
	$email = $_POST['email'];
	$website = $_POST['website'];
	$message = $_POST['message'];

	$image = $_FILES['image']['name'];
	$imagetmp = $_FILES['image']['image_tmp'];
	$store = "images/".$image;

	move_uploaded_file($imagetmp, $store);
	
	
	
	
	$query = "INSERT INTO diagnostic(category, centre, year, services, emergency, management, degree, address, state, district, area, phone_number, mobilenumber1, mobilenumber2, email, website, message,  image) VALUES('$category', '$centre', '$year', '$services', '$emergency', '$management', '$degree', '$address', '$state', '$district', '$area', '$phone_number', '$mobile_number1', '$mobile_number2', '$email', '$website', '$message', '$store' )";

	$query = mysqli_query($con, $query);
	
	if($query===FALSE)
	{
	 		echo "<center><font size = '5' color='blue'>Don't Store In Data Plz Try Again.....?</font></center>";
	 		}
	 		else
			{
	 			
	 			echo "<center><b><font size = '5' color='white'>Data Store In Sucssesfully.....?</font></b></center>";
	 		}

	}

?>