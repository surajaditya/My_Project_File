<?php include('config.php') ;?>
<!DOCTYPE html>
<html>
<head>
	<title> Upload file</title>
</head>
<body bgcolor="#1E90FF">
  <div class="container">
		<hr>

	<?php 
	  if(isset($_POST['uploadBtn'])){
	  	$fileName = $_FILES['myfile']['name'];
	  	$fileTmpName = $_FILES['myfile']['tmp_name'];
	  	//lets find the extension of file 
	  	$fileExtension = pathinfo($fileName,PATHINFO_EXTENSION);

	  	//echo $fileExtension;
	  	//define your allowed extension
	  	$allowedType = array('csv');
	  	if(!in_array($fileExtension, $allowedType)){?>
	  		<div class="alert alert-danger"> Invalid File Extension</div>
	  	<?php } else{
                //upload your file 
	  		$handle = fopen($fileTmpName, 'r'); //read mode 'r'
	  		while (($myData = fgetcsv($handle,1000,',')) !== FALSE){
	  			$name = $myData['0'];
	  			$email = $myData['1'];

	  			$query = "INSERT INTO csv (name, email) VALUES('$name', '$email')";
	  			$run = mysqli_query($con, $query);

	  		}
	  		if (!$run) {
	  			die("error in uploading file".mysqli_error($con));
	  		}else{?>
                  <div class="alert alert-success"> File Uploaded Successfully</div>
	  		<?php }
	  	}
	  }
	  ?>
		 <form action="" method="post" enctype="multipart/form-data" align="center">
		 	<h3 class="text-center"> Uploads Excel File
		 	</h3><hr/>
		 <div class ="row">
		   <div class="col-md-6">
		     <input type="file" name="myfile" class="form-control">
		     </div>
		    </div>
		    <div class="row">
		    	<div class="col-md-6">
		    		<div class="form-group">
		    			<input type="submit" name="uploadBtn" class="btn btn-info">
		    			
		    		</div>
		    		
		    	</div> 
		    	
		    </div>

		 	
		 </form>

</body>
</html>