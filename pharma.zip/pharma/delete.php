
<?php 

$con=mysqli_connect("localhost","root","") or die("Unable to connect");
mysqli_select_db($con,'pharma');

$id = $_GET ['id'];

$query = "delete from medical where id = '$id'";

if (mysqli_query ($con, $query )) 
{
	
	echo "Data Delete Successfully";
} 
else
{
	echo " Not Delete data";
}

 ?>