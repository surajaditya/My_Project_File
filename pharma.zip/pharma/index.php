<?php
$con=mysqli_connect("localhost","root","") or die("Unable to connect");
mysqli_select_db($con,'pharma');

if(isset($_POST['submit'])){
	$category = $_POST['category'];
	$name = $_POST['name'];
	$owner = $_POST['owner'];
	$year = $_POST['year'];
	$emergency = $_POST['emergency'];
	$address = $_POST['address'];
	$state = $_POST['state'];
	$district = $_POST['district'];
	$area = $_POST['area'];
	$phone_number = $_POST['phone_number'];
	$mobile_number1 = $_POST['mobilenumber1'];
	$mobile_number2 = $_POST['mobilenumber2'];
	$email = $_POST['email'];
	$website = $_POST['website'];
	$message = $_POST['message'];

	$image = $_FILES['image']['name'];
	$imagetmp = $_FILES['image']['imagetmp'];
	$store = "images/".$image;

	move_uploaded_file($imagetmp, $store);
	
	
	
	
	$query = "INSERT INTO medical(category, name, owner, year, emergency, address, state, district, area, phone_number, mobilenumber1, mobilenumber2, email, website, message,  image) VALUES('$category', '$name', '$owner', '$year', '$emergency', '$address', '$state', '$district', '$area', '$phone_number', '$mobile_number1', '$mobile_number2', '$email', '$website', '$message', '$store' )";

	$query = mysqli_query($con, $query);
	
	if($query===FALSE)
	{
	 		echo "<center><font size = '5' color='blue'>Don't Store In Data Plz Try Again.....?</font></center>";
	 		}
	 		else
			{
	 			
	 			echo "<center><b><font size = '5' color='white'>Data Store In Sucssesfully.....?</font></b></center>";
	 		}

	}

?>