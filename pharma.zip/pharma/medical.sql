-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2018 at 06:53 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `medical`
--

CREATE TABLE `medical` (
  `id` int(10) NOT NULL,
  `category` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `owner` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `emergency` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `phone_number` varchar(12) NOT NULL,
  `mobilenumber1` varchar(12) NOT NULL,
  `mobilenumber2` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `image` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medical`
--

INSERT INTO `medical` (`id`, `category`, `name`, `owner`, `year`, `emergency`, `address`, `state`, `district`, `area`, `phone_number`, `mobilenumber1`, `mobilenumber2`, `email`, `website`, `message`, `image`) VALUES
(3, 'Eye Bank', 'suraj', 'suraj', '2018', 'Available 24x7', 'ghsdghgdj', 'Delhi', 'Mayur Vihar', 'Chilla Village', '989898989', '989898988', '898988988', 'surajadi@gmail.com', 'cars24.com', 'kjhkasghsdghgdsh', 'images/panda1.png'),
(7, 'Pathology Centre', 'suraj', 'suraj', '2018', 'Available 24x7', 'chilla village mayur vihar ', 'Delhi', 'Mayur Vihar', 'Chilla Village', '7777777777', '8888888888', '9999999999', 'surajadi@gmail.com', 'cars24.com', 'hey world', 'images/glb.jpg'),
(8, 'Blood Bank', 'suraj', 'suraj', '2017', 'Available 24x7', 'asasa', 'Delhi', 'Mayur Vihar', 'Chilla Village', '7878787788', '78787878778', '787878787', 'surajadi@gmail.com', 'cars24.com', 'sskajsdlkjksd', 'images/s.jpg'),
(9, 'Radiodiagnosis Centre', 'raj', 'raj', '2011', 'Available 24x7', 'jkxzhgdkjsgkj', 'Delhi', 'Mayur Vihar', 'Chilla Village', '7878787', '7878787', '78787877', 'surajadi@gmail.com', 'cars24.com', 'sanjsdj', 'images/panda1.png'),
(10, 'Eye Bank', 'suraj', 'suraj', '2018', 'Available 24x7', 'hgdhdfhdhd', 'Delhi', 'Mayur Vihar', 'Chilla Village', '787878', '788787', '8787787', 'surajadi@gmail.com', 'cars24.com', 'jkhghjgjhjg', 'images/s.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medical`
--
ALTER TABLE `medical`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medical`
--
ALTER TABLE `medical`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
