<!DOCTYPE html>
<html>
<head>
	<title> Show Of Pharma</title>
</head>
<body>
	<?php 
     $con=mysqli_connect("localhost","root","") or die("Unable to connect");
     mysqli_select_db($con,'pharma');

     $query="SELECT * FROM medical";
     $data=mysqli_query($con, $query);
     $total=mysqli_num_rows($data);
     if ($total!=0)
     {

	?>

  <table border="1">
  	<h2 align="center"> Pharma Data</h2>

  	<tr>
  		<td>ID</td>
  		<td>Catogory</td>
  		<td>Name Of Firm</td>
  		<td>Name Of Owner/Contact People</td>
  		<td>Establishment Year</td>
  		<td>Emergency Services Available</td>
  		<td>Address</td>
  		<td>State</td>
  		<td>District</td>
  		<td>Geographical Area</td>
  		<td>Phone No</td>
  		<td>Mobile_Number 1</td>
  		<td>Mobile_Number 2</td>
  		<td>Email.Id</td>
  		<td>Website</td>
  		<td>Tell People more about your services</td>
  		<td>Photo/Logo</td>
  		<td>Action</td>
  		<td>Action</td>
  	</tr>
  	<?php
	while($result=mysqli_fetch_assoc($data))
	{
		$id=$result['id'];
		echo "<tr>;
		
		<td>".$result['id']."</td>
		<td>".$result['category']."</td> 
		<td>".$result['name']."</td>
		<td>".$result['owner']."</td>
		<td>".$result['year']."</td>
		<td>".$result['emergency']."</td>
		<td>".$result['address']."</td>
		<td>".$result['state']."</td>
		<td>".$result['district']."</td>		
		<td>".$result['area']."</td>
		<td>".$result['phone_number']."</td> 
		<td>".$result['mobilenumber1']."</td>
		<td>".$result['mobilenumber2']."</td>
		<td>".$result['email']."</td>
		<td>".$result['website']."</td>
		<td>".$result['message']."</td>
		<td>".$result['image']."</td>
		

		
		
		<td>"?> <a href="pharmaupdate.php?id=<?php echo $id; ?>">UPDATE </a> <?php echo "</td>
		<td>"?><a href="pharmadelete.php?id=<?php echo $id; ?>">DELETE </a> <?php echo "</td> 
		 
		 
		</tr>";
	}
}else
{
	echo"Table has not record";
	
}
	
		?>
		</table>
	</body>
	</html>