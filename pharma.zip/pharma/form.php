<html>
<head>
	<title>Diagnostic Form</title>
  </head>
   <body bgcolor="#87CEFA">
   	<hr>
	<h2 align="center"> Add Pharma Centre in Directory </h2>
	<hr>
  <form action="pharma.php" method="POST" width="100%" enctype="multipart/form-data">
 
<table border="4" bordercolor="grey" align="center" width="40%" >
 
<!----- Category ---------------------------------------------------------->
<tr>
<td>Category</td>
 <td >
    <select name="category">
      <option>Nothing Selected</option>
      <option>Ayurvedic Medicine Store</option>
      <option>Dental Equipment Dealer</option>
      <option>General Medical Store</option>
      <option>Homoeopathic Medicine Store</option>
      <option>Medical Equipment Dealer</option>
      <option>Pharma Wholesaler-Distributor</option>
      <option>Pharmaceutical Company</option>
  </select>
</td>
  
</tr>
 
<!----- name of firm ---------------------------------------------------------->
<tr>
<td>Name Of Firm </td>
<td><input type="text" name="name" placeholder=" Name Of firm">
</td>
</tr>

<!--------- Owner/Contact Person----------------------------------------------------->
<tr>
<td>Name Of Owner/Contact Person </td>
<td><input type="text" name="owner" placeholder=" Name of Owner/Contact Person">
</td>
</tr>

<!----- Establishment Year---------------------------------------------------------->
<tr>
<td>Establishment Year </td>
<td><input type="year" name="year" placeholder="Establishment Year"></td>
</tr>

<!----- Emergency ---------------------------------------------------------->
<tr>
<td>Emergency Service availablity </td>
<td>
	<select name="emergency">
		<option>Nothing Selected</option>
		<option>Available 24x7</option>
		<option>Not Available</option>
	</select>
</td>
</tr>
 
<!----- Address With Opening Hours---------------------------------------------------------->
<tr>
<td>Address With Opening Hours</td>
<td><textarea name="address" rows="2" cols="30"></textarea></td>
</tr>
 
<!----- State ---------------------------------------------------------->
<tr>
<td>State</td>
<td>
	<select name="state">
		<option>Nothing Selected</option>
		<option>Delhi</option>
		<option>Panjab</option>
	</select>
</td>
</tr>
 
<!----- District ---------------------------------------------------------->
<tr>
<td>District</td>
<td>
	<select name="district">
		<option>.....................</option>
		<option>Mayur Vihar</option>
		<option>ludiyana</option>
	</select>
</td>
</tr>
 
<!----- Geographical Area ---------------------------------------------------------->
<tr>
<td>Geographical Area</td>
<td>
	<select name="area">
		<option>.....................</option>
		<option>Chilla Village</option>
        <option>Sardar Mohhala</option>
	</select>
</td>
</tr>
 
<!----- Phone Number ---------------------------------------------------------->
<tr>
<td>Phone Number</td>
<td><input type="Number" name="phone_number" value="Number" placeholder="Phone Number"></td>
</tr>
 
<!----- mobile No 1---------------------------------------------------------->
 
<tr>
<td>Mobile Number 1</td>
<td><input type="Number" name="mobilenumber1" value="Number" placeholder="Mobile  Number 1"></td>
</tr>

<!----- Mobile Number 2 ---------------------------------------------------------->
<tr>
<td>Mobile Number 2</td>
<td><input type="Number" name="mobilenumber2" value="Number" placeholder="Mobile Number 2"></td>
</tr>

<!----- Email Id---------------------------------------------------------->
<tr>
<td>Email Id</td>
<td><input type="email" name="email" placeholder="Email Id"></td>	
</tr>
 
<!----- Website---------------------------------------------------------->
<tr>
<td>Website</td>
<td><input type="text" name="website" placeholder="Website"></td>	
</tr>
 
 <!----- Message ---------------------------------------------------------->
<tr>
<td>Tell people more about your services</td>
<td><textarea name="message" rows="3" cols="40"></textarea>
</td>
</tr>

<!----- Photo/Logo ---------------------------------------------------------->
<tr>
<td>Photo/Logo </td>
<td><input type="file" name="image" /></td>
</tr>
 
<!----- Submit and Reset ------------------------------------------------->
<tr>
<td colspan="2" align="center">
<input type="submit" name="submit" value="Submit">
<input type="reset" name="reset" value="Reset">
</td>
</tr>
</table>
 
</form>
</body>
</html>



