<?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="inner-banner-content">
                    <h1 class="inner-banner-title">Web Hosting Services</h1>
                    <ul class="breadcumbs list-inline">
                        <li><a href="index.php">Home</a></li>
                        <li>Services</li>
                    </ul>
                    <span class="border-divider style-white"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- cases section -->
<section class="xs-section-padding">
    <div class="container">
        <center><h2>Web Hosting</h2></center>
        <div class="cases-grid">
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/linux.jpg" alt="">
                        <div class="hover-area">
                            <a href="linux-hosting.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="linux-hosting.php">Linux Hosting</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/window-hosting.jpg" alt="window-hosting">
                        <div class="hover-area">
                            <a href="windows-hosting.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="windows-hosting.php">Windows Hosting</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/Linux-Reseller-Hosting.jpg" alt="Linux-Reseller-Hosting">
                        <div class="hover-area">
                            <a href="linux-reseller-hosting.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="linux-reseller-hosting.php">Linux Reseller Hosting</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/windows-hosting.jpg" alt="windows-hosting">
                        <div class="hover-area">
                            <a href="windows-reseller-hosting.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="windows-reseller-hosting.php">Windows Reseller Hosting</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/best-vps-hosting-providers.jpg" alt="">
                        <div class="hover-area">
                            <a href="vps-servers.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="vps-servers.php">VPS Servers</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/dedicated-server.png" alt="dedicated-server">
                        <div class="hover-area">
                            <a href="dedicated-servers.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="dedicated-servers.php">Dedicated Servers</a>
                        </h2>

                    </div> 
                </div>
            </div>
          </div>
    </div>
</section>

<!-- call to action section -->
<section class="call-to-action-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="call-to-action-content">
                    <h2>Interested To Get Our Featured Service</h2>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="btn-wraper">
                    <a href="contact.php" class="btn btn-info icon-right"><i class="icon icon-arrow-right"></i>Get Started Now</a>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'footer.php';?>
