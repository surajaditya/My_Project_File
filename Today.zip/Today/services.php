<?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="inner-banner-content">
                    <h1 class="inner-banner-title">Our Services Studies</h1>
                    <ul class="breadcumbs list-inline">
                        <li><a href="index.php">Home</a></li>
                        <li>Services</li>
                    </ul>
                    <span class="border-divider style-white"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- cases section -->
<section class="xs-section-padding">
    <div class="container">
        <center><h2>Our Services</h2></center>
        <div class="cases-grid">
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/Social-Media.jpg" alt="Social-Media">
                        <div class="hover-area">
                            <a href="social-services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="social-services.php">SOCIAL MEDIA SERVICES</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/website-solutions.jpg" alt="website-solutions">
                        <div class="hover-area">
                            <a href="websit-services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="websit-services.php">WEBSITE SERVICES</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/App-Store-Optimization.jpg" alt="App-Store-Optimization">
                        <div class="hover-area">
                            <a href="apps-marketing.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="apps-marketing.php">APPS MARKETING</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/sms-promotion.jpg" alt="sms-promotion">
                        <div class="hover-area">
                            <a href="sms-services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="sms-services.php">SMS SERVICES</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/web-hosting.jpg" alt="Hosting">
                        <div class="hover-area">
                            <a href="web-hosting.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="web-hosting.php">WEB HOSTING</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/email-promotion.png" alt="email-promotion">
                        <div class="hover-area">
                            <a href="email-services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="email-services.php">EMAIL SERVICES</a>
                        </h2>

                    </div> 
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/video-marketing.jpg" alt="video-marketing">
                        <div class="hover-area">
                            <a href="case-details.html"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="case-details.html">VIDEO ENGIN MARKETING </a>
                        </h2>

                    </div> 
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/ivr-services.png" alt="ivr-services">
                        <div class="hover-area">
                            <a href="case-details.html"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="case-details.html">IVR SERVICES</a>
                        </h2>

                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>

<!-- call to action section -->
<section class="call-to-action-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="call-to-action-content">
                    <h2>Interested To Get Our Featured Service</h2>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="btn-wraper">
                    <a href="contact.php" class="btn btn-info icon-right"><i class="icon icon-arrow-right"></i>Get Started Now</a>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'footer.php';?>
