<?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="inner-banner-content">
                    <h1 class="inner-banner-title">APPS Marketing</h1>
                    <ul class="breadcumbs list-inline">
                        <li><a href="index.php">Home</a></li>
                        <li>Services</li>
                    </ul>
                    <span class="border-divider style-white"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- cases section -->
<section class="xs-section-padding">
    <div class="container">
        <center><h2>APPS Marketing</h2></center>
        <div class="cases-grid">
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/images/cases-card/cases-card-1.png" alt="">
                        <div class="hover-area">
                            <a href="social-services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="social-services.php">Android Apps Creation</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/images/cases-card/cases-card-2.png" alt="">
                        <div class="hover-area">
                            <a href="case-details.html"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="case-details.html">IOS Apps Creation</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/images/cases-card/cases-card-3.png" alt="">
                        <div class="hover-area">
                            <a href="case-details.html"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="case-details.html">Android Apps Promotion</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/images/cases-card/cases-card-4.png" alt="">
                        <div class="hover-area">
                            <a href="sms-services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="sms-services.php">IOS Apps Promotion</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/images/cases-card/cases-card-5.png" alt="">
                        <div class="hover-area">
                            <a href="case-details.html"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="case-details.html">Apps Downloads And Installs</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/images/cases-card/cases-card-6.png" alt="">
                        <div class="hover-area">
                            <a href="case-details.html"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="case-details.html">Apps Ratting And Review</a>
                        </h2>

                    </div> 
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/images/cases-card/cases-card-6.png" alt="">
                        <div class="hover-area">
                            <a href="case-details.html"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="case-details.html">Advertising On  Apps</a>
                        </h2>

                    </div> 
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/images/cases-card/cases-card-6.png" alt="">
                        <div class="hover-area">
                            <a href="case-details.html"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="case-details.html">Google Play Developer Account</a>
                        </h2>

                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>

<!-- call to action section -->
<section class="call-to-action-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="call-to-action-content">
                    <h2>Interested To Get Our Featured Service</h2>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="btn-wraper">
                    <a href="contact.php" class="btn btn-info icon-right"><i class="icon icon-arrow-right"></i>Get Started Now</a>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'footer.php';?>
