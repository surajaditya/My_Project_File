<?php
if(isset($_POST['sub'])){
 $name=$_POST['name'];
 $email=$_POST['email'];
 $mobile=$_POST['mobile'];
 $subject=$_POST['subject'];
 $message=$_POST['message']; 
 
	$subject = "Enquiry from $subject";
	$txt = "
	<html>
	<head>
	<title>TODAY WEB TECHNOLOGY</title>
	</head>
	<body>

	<table border='1px'>



	<tr>
	<td>Name</td>
	<td>$name</td>
	</tr>

	<tr>
	<td>Email</td>
	<td>$email</td>
	</tr>
	<tr>
	<td>Mobile</td>
	<td>$mobile</td>
	</tr>
	<td>Subject</td>
	<td>$subject</td>
	</tr>
	<tr>
	<td>Message</td>
	<td>$message</td>
	</tr>

	</table>
	</body>
	</html>




	";
	$too = "info@todaywebtechnology.com";
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";



	$headers .= 'From: <todaywebtechnology.com>' . "\r\n";


	mail($too,$subject,$txt,$headers);
	if(mail==true){
    echo "<script>window.open('index.php','_self')</script>";
	}
	else{
		echo "error";
	}


}
?>

