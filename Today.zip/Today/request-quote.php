<?php
if(isset($_POST['sub'])){
 $email=$_POST['email'];
 $message=$_POST['message']; 
 
	$subject = "Request a quote $email";
	$txt = "
	<html>
	<head>
	<title>TODAY WEB TECHNOLOGY</title>
	</head>
	<body>

	<table border='1px'>



	 

	<tr>
	<td>Email</td>
	<td>$email</td>
	</tr>
	<tr>
	<td>Message</td>
	<td>$message</td>
	</tr>

	</table>
	</body>
	</html>




	";
	$too = "info@todaywebtechnology.com";
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";



	$headers .= 'From: <todaywebtechnology.com>' . "\r\n";


	mail($too,$subject,$txt,$headers);
	if(mail==true){
    echo "<script>window.open('index.php','_self')</script>";
	}
	else{
		echo "error";
	}


}
?>

