 <?php include 'header.php';?>
 <!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="inner-banner-content">
					<h1 class="inner-banner-title">Get in Touch</h1>
					<ul class="breadcumbs list-inline">
						<li><a href="index.php">Home</a></li>
						<li>Contact</li>
					</ul>
					<span class="border-divider style-white"></span>
				</div>
			</div>
		</div>
	</div>
	<div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- contact info strart -->
<section class="xs-section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="xs-heading text-center style4">
                    <h2 class="section-title">Get in Touch</h2>
                    <span class="line"></span>
                    <p>This page displays the contact details of all the Officers and Officials of the Directorate of Education from the Secretary of Today Web Technology</p>
                </div><!-- .xs-heading END -->
            </div>
        </div><!-- .row END -->
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="contact-info-wraper">
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="single-contact-info">
                                <div class="round-icon">
                                    <i class="icon icon-map-marker2"></i>
                                </div><!-- .round-icon END -->
                                <a href="https://goo.gl/maps/xUAMnDfrrh92">C-40/4 Om Vihar , Dayal Sar Uttam Nagar West,New Delhi, INDIA </a>
                            </div><!-- .single-contact-info END -->
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="single-contact-info">
                                <div class="round-icon">
                                    <i class="icon icon-phone-call3"></i>
                                </div><!-- .round-icon END -->
                                <a href="#" class="info-content">+91-9871819682</a>
                                <a href="#" class="info-content">+91-8527712185</a>
                            </div><!-- .single-contact-info END -->
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="single-contact-info">
                                <div class="round-icon">
                                    <i class="icon icon-envelope4"></i>
                                </div><!-- .round-icon END -->
                                <a href="mailto:info@todaywebtechnology.com" class="info-content">info@todaywebtechnology.com</a>
                                <a href="ceo@todaywebtechnology.com" class="info-content">ceo@todaywebtechnology.com</a>
                            </div><!-- .single-contact-info END -->
                        </div>
                    </div><!-- .row END -->
                </div><!-- .contact-info-wraper END -->
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- end contact info -->

<!-- map area strart -->
<div class="map-area">
    <div class="container">
        <div id="map-1">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.266998351243!2d77.05362241455936!3d28.621758891320507!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d05279b249541%3A0xb1df17d0024afcd9!2sUttam+Nagar+West!5e0!3m2!1sen!2sin!4v1548055411326" width="600" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
    </div><!-- .container END -->
</div><!-- end map area -->

<!-- contact strart -->
<section class="xs-section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-8 mx-auto">
                <div class="xs-heading text-center style4">
                    <h3 class="section-title">Drop us a Line</h3>
                    <span class="line"></span>
                    <p>This page displays the contact details of all the Officers and Officials of the Directorate of Education from the Secretary of Technology, the Director of Technology till the Assistant Director of Technology.  The list contains the designation, the office phone number, the residence phone number and the Fax number of every officer.  An Intra e-Mail link is available for every officer to be communicated with.</p>
                </div><!-- .xs-heading END -->
            </div>
        </div><!-- .row END -->
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="contact-from-wraper wow fadeIn">
                    <form action="contact-mail.php" class="xs-from" method="post">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" placeholder="Name *">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control" placeholder="Mail *">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <input type="number" name="mobile"  class="form-control" placeholder="Phone *">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <input type="text" name="subject" class="form-control" placeholder="Subject">
                                </div>
                            </div>
                        </div><!-- .row END -->
                        <div class="form-group">
                            <textarea name="message" class="form-control" placeholder="Your Message *" cols="30" rows="10"></textarea>
                        </div>
                        <div class="text-center">
                            <input type="submit" name="sub" value="Submit" class="btn btn-primary style2" >
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section> 
<!-- sidebar cart item -->
<div class="xs-sidebar-group info-group">
    <div class="xs-overlay black-bg"></div>
    <div class="xs-sidebar-widget">
        <div class="sidebar-widget-container">
            <div class="widget-heading">
                <a href="#" class="close-side-widget">
                    <i class="icon icon-cross"></i>
                </a>
            </div>
            <div class="sidebar-textwidget">
                <div class="sidebar-logo-wraper">
                    <a href="index-2.html">
                        <img src="assets/images/logo.png" alt="sidebar logo">
                    </a>
                </div>
                <p>Far far away, behind the word moun tains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of  </p>
                <ul class="sideabr-list-widget">
                    <li>
                        <div class="media">
                            <div class="d-flex">
                                <img src="assets/images/location.png" alt="">
                            </div>
                            <div class="media-body">
                                <p>759 Pinewood Avenue</p>
                                <span>Marquette, Michigan</span>
                            </div>
                        </div><!-- address 1 -->
                    </li>
                    <li>
                        <div class="media">
                            <div class="d-flex">
                                <img src="assets/images/mail.png" alt="">
                            </div>
                            <div class="media-body">
                                <a href="mailto:info@domain.com">info@domain.com</a>
                                <span>Online Support</span>
                            </div>
                        </div><!-- address 1 -->
                    </li>
                    <li>
                        <div class="media">
                            <div class="d-flex">
                                <img src="assets/images/phone.png" alt="">
                            </div>
                            <div class="media-body">
                                <p>906-624-2565</p>
                                <span>Mon-Fri 8am-5pm</span>
                            </div>
                        </div><!-- address 1 -->
                    </li>
                </ul><!-- .sideabr-list-widget -->
                <div class="subscribe-from">
                    <p>Get Subscribed!</p>
                    <form action="#" method="POST" class="subscribe-form">
                        <label for="sub-input"></label>
                        <div class="form-group">
                            <input type="email" name="email" id="sub-input" placeholder="Enter your mail here" class="form-control">
                            <button class="sub-btn" type="submit"><i class="icon icon-arrow-right"></i></button>
                        </div>
                    </form>
                </div>
                <ul class="social-list version-2">
                    <li><a href="https://www.facebook.com/" class="facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/" class="twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://bd.linkedin.com/" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="https://www.instagram.com/" class="instagram"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="https://vimeo.com/" class="vimeo"><i class="fa fa-vimeo"></i></a></li>
                </ul><!-- .social-list -->
                <div class="text-center">
                    <a href="#" class="btn btn-primary">Purchase Now</a>
                </div>
            </div>
        </div>
    </div>
</div>    
<?php include 'footer.php';?>