 <?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="inner-banner-content">
					<h1 class="inner-banner-title">About Our Agency</h1>
					<ul class="breadcumbs list-inline">
						<li><a href="index.php">Home</a></li>
						<li>About</li>
					</ul>
					<span class="border-divider style-white"></span>
				</div>
			</div>
		</div>
	</div>
	<div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- Nrutpu info section -->
<section class="xs-section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 align-self-center">
                <div class="xs-info-wraper style2 wow fadeInUp">
                    <div class="xs-heading">
                        <h2 class="section-title">We Provide Best<br>  Services In Today Web Technology</h2>
                        <span class="line"></span>
                    </div>
                    <p>We put together a custom digital marketing plan for you that is based on your business’ goals. Then we execute the plan on a monthly basis.</p>
                    <p>The plan breaks into three critical parts: <li>Attract More Prospects – Gain more website traffic through content marketing (blogging), email marketing, search engine optimization (SEO), pay-per-click marketing (PPC) and social media.</li><li>Convert More Leads – Once you have more traffic on your website, you need to convert the traffic from an anonymous website visitor to an identifiable lead.We do this through irresistible downloadable content offers (like ebooks), lead nurturing via email, A/B testing and compelling videos.</li><li>Close More Sales – Leads are no good if they don’t close. We empower your sales team with new tools and data to help them close more of the leads we send.</li></p>
                </div><!-- .xs-info-wraper END -->
            </div>
            <div class="col-lg-6">
                <div class="video-popup-wraper">
                    <div class="xs-info-img">
                        <img src="assets/images/info/info-1.png" alt="">
                    </div>
                    <div class="video-content text-center">
                        <a href="https://www.youtube.com/watch?v=dnGs2eOE6hQ" class="xs-video-popup video-popup-btn pulse-effect">
                            <i class="icon icon-play2"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- END Nrutpu info section -->

<!-- working process section -->
<section class="xs-section-padding primary-bg working-process-anim">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="xs-heading text-center">
                    <h2 class="section-subtitle">Work Flow</h2>
                    <h3 class="section-title ">Our Working Process</h3>
                </div><!-- .xs-heading END -->
            </div>
        </div>
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="row no-gutters working-process-group">
                    <div class="col-lg-3 col-md-6">
                        <div class="single-work-process">
                            <div class="work-process-icon">
                                <img src="assets/images/work-process/1.png" alt="">
                            </div>
                            <h4 class="small">Planning</h4>
                        </div><!-- .single-work-process END -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-work-process">
                            <div class="work-process-icon">
                                <img src="assets/images/work-process/2.png" alt="">
                            </div>
                            <h4 class="small">Research</h4>
                        </div><!-- .single-work-process END -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-work-process">
                            <div class="work-process-icon">
                                <img src="assets/images/work-process/3.png" alt="">
                            </div>
                            <h4 class="small">Optimizing</h4>
                        </div><!-- .single-work-process END -->
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-work-process">
                            <div class="work-process-icon">
                                <img src="assets/images/work-process/4.png" alt="">
                            </div>
                            <h4 class="small">Results</h4>
                        </div><!-- .single-work-process END -->
                    </div>
                </div><!-- .row end -->
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- END working process section -->

<!-- fun fact section -->
<section class="xs-section-padding waypoint-tigger">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="xs-heading style3 wow fadeIn text-center">
                    <h3 class="section-title"><span>Google</span> only loves you <br> when everyone else <span>love</span> you first</h3>
                    <span class="line"></span>
                </div>
            </div>
        </div><!-- .row END -->
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="row funfact-wraper no-gutters">
                    <div class="col-md-4">
                        <div class="single-funfact wow fadeIn text-center" data-wow-duration="1s">
                            <span class="number-percentage-count number-percentage" data-value="32548" data-animation-duration="10000">0</span>
                            <p>Happy Clients</p>
                        </div><!-- .single-funfact END -->
                    </div>
                    <div class="col-md-4">
                        <div class="single-funfact wow fadeIn text-center" data-wow-duration="1.2s">
                            <span class="number-percentage-count number-percentage" data-value="4295" data-animation-duration="10000">0</span><span>+</span>
                            <p>Works Done</p>
                        </div><!-- .single-funfact END -->
                    </div>
                    <div class="col-md-4">
                        <div class="single-funfact wow fadeIn text-center" data-wow-duration="1.4s">
                            <span class="number-percentage-count number-percentage" data-value="25498" data-animation-duration="10000">0</span>
                            <p>Subscribers</p>
                        </div><!-- .single-funfact END -->
                    </div>
                </div><!-- .row end -->
            </div>
        </div><!-- .row end -->
        <div class="btn-wraper text-center">
            <a href="#" class="btn btn-primary style2 icon-left"><i class="icon icon-envelope4"></i> Click here to get Subscribe</a>
        </div>
    </div><!-- .container END -->
</section><!-- END fun fact section -->

<!-- Nrutpu info section -->
<section class="xs-section-padding gray-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 align-self-center">
                <div class="xs-info-wraper style2 wow fadeInUp">
                    <div class="xs-heading">
                        <h3 class="section-title">Our Vision</h3>
                        <span class="line"></span>
                    </div>
                    <p>The program is executed on a monthly retainer basis. After an initial research and planning phase, we provide you with a custom digital marketing plan to reach your business goals, and then we execute on that plan. The program is customized based on your company, your competition and your industry. The initial strategic plan we provide outlines the tactics to be executed over the following 12 months.<br>We have weekly check-in meetings with you to ensure all projects stay on track. We also have monthly meetings to present our reports outlining the program’s performance (focused on traffic and lead improvement). In our monthly meeting we also review the following month’s plan (broken into a monthly calendar of tactics).<br>We firmly believe that “what you cannot measure, you cannot improve.” So we measure and provide comprehensive reports every month. These reports will detail our progress towards your goals and include metrics like website traffic, form submissions, downloads, leads created,leads closed and even phone calls to your sales number.</p>
                    <ul class="xs-list check">
                        <p>We have a dedicated team committed to your business. Your team will consist of:</p>
                        <li>Strategist</li>
                        <li>Senior consultant</li>
                        <li>Consultant</li>
                        <li>SEO expert</li>
                        <li>Content strategist</li>
                        <li>Copywriter</li>
                        <li>Graphic designer</li>
                        <li>Web developer</li>
                        <li>Social media specialist</li>
                        <li>Photographer & Videographer</li>
                    </ul>
                    <div class="btn-wraper">
                        <a href="services.php" class="btn btn-primary style2 icon-right"><i class="icon icon-arrow-right"></i>Get Our Service</a>
                    </div>
                </div><!-- .xs-info-wraper END -->
            </div>
            <div class="col-lg-6">
                <div class="xs-info-img ab">
                    <img src="assets/images/info/info-2.png" alt="">
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- END Nrutpu info section -->
 

<!-- we are hiring section -->
<section class="xs-section-padding pt-0">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="hiring-image">
                    <img src="assets/images/info/info-3.jpg" alt="">
                </div>
            </div>
            <div class="col-md-7">
                <div class="hiring-content">
                    <h2><span>We’re Hiring!</span> Interested to working with our Team?</h2>
                    <a href="contact.php" class="btn btn-primary style2 icon-left"><i class="icon icon-envelope4"></i> Drop you resume here</a>
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- end we are hiring section -->

<!-- language switcher strart -->
<!-- xs modal -->
<div class="zoom-anim-dialog mfp-hide modal-language" id="modal-popup-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="language-content">
                <p>Switch The Language</p>
                <ul class="flag-lists">
                    <li><a href="#"><img src="assets/images/flags/006-united-states.svg" alt=""><span>English</span></a></li>
                    <li><a href="#"><img src="assets/images/flags/002-canada.svg" alt=""><span>English</span></a></li>
                    <li><a href="#"><img src="assets/images/flags/003-vietnam.svg" alt=""><span>Vietnamese</span></a></li>
                    <li><a href="#"><img src="assets/images/flags/004-france.svg" alt=""><span>French</span></a></li>
                    <li><a href="#"><img src="assets/images/flags/005-germany.svg" alt=""><span>German</span></a></li>
                </ul>
            </div>
        </div>
    </div>
</div><!-- End xs modal --><!-- end language switcher -->

<!-- search panel strart -->
<!-- xs modal -->
<div class="zoom-anim-dialog mfp-hide modal-searchPanel" id="modal-popup-2">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="xs-search-panel">
                <form action="#" method="POST" class="xs-search-group">
                    <input type="search" class="form-control" name="search" id="search" placeholder="Search">
                    <button type="submit" class="search-button"><i class="icon icon-search"></i></button>
                </form>
            </div>
        </div>
    </div>
</div><!-- End xs modal --><!-- end search panel -->

<!-- offset cart strart -->
<!-- sidebar cart item -->
<div class="xs-sidebar-group cart-group">
    <div class="xs-overlay black-bg"></div>
    <div class="xs-sidebar-widget">
        <div class="sidebar-widget-container">
            <div class="widget-heading media">
                <div class="media-body">
                    <a href="#" class="close-side-widget">
                        <i class="icon icon-cross"></i>
                    </a>
                </div>
            </div>
            <div class="xs-empty-content">
                <h3 class="widget-title">Shopping cart</h3>
                <h4 class="xs-title">No products in the cart.</h4>
                <p class="empty-cart-icon">
                    <i class="icon icon-shopping-cart"></i>
                </p>
                <p class="xs-btn-wraper">
                    <a class="btn btn-primary" href="shop.html">Return To Shop</a>
                </p>
            </div>
        </div>
    </div>
</div>    <!-- END sidebar cart item -->    <!-- END offset cart -->

<!-- offset cart strart -->
<!-- sidebar cart item -->
<div class="xs-sidebar-group info-group">
    <div class="xs-overlay black-bg"></div>
    <div class="xs-sidebar-widget">
        <div class="sidebar-widget-container">
            <div class="widget-heading">
                <a href="#" class="close-side-widget">
                    <i class="icon icon-cross"></i>
                </a>
            </div>
            <div class="sidebar-textwidget">
                <div class="sidebar-logo-wraper">
                    <a href="index-2.html">
                        <img src="assets/images/logo.png" alt="sidebar logo">
                    </a>
                </div>
                <p>Far far away, behind the word moun tains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of  </p>
                <ul class="sideabr-list-widget">
                    <li>
                        <div class="media">
                            <div class="d-flex">
                                <img src="assets/images/location.png" alt="">
                            </div>
                            <div class="media-body">
                                <p>759 Pinewood Avenue</p>
                                <span>Marquette, Michigan</span>
                            </div>
                        </div><!-- address 1 -->
                    </li>
                    <li>
                        <div class="media">
                            <div class="d-flex">
                                <img src="assets/images/mail.png" alt="">
                            </div>
                            <div class="media-body">
                                <a href="mailto:info@domain.com">info@domain.com</a>
                                <span>Online Support</span>
                            </div>
                        </div><!-- address 1 -->
                    </li>
                    <li>
                        <div class="media">
                            <div class="d-flex">
                                <img src="assets/images/phone.png" alt="">
                            </div>
                            <div class="media-body">
                                <p>906-624-2565</p>
                                <span>Mon-Fri 8am-5pm</span>
                            </div>
                        </div><!-- address 1 -->
                    </li>
                </ul><!-- .sideabr-list-widget -->
                <div class="subscribe-from">
                    <p>Get Subscribed!</p>
                    <form action="#" method="POST" class="subscribe-form">
                        <label for="sub-input"></label>
                        <div class="form-group">
                            <input type="email" name="email" id="sub-input" placeholder="Enter your mail here" class="form-control">
                            <button class="sub-btn" type="submit"><i class="icon icon-arrow-right"></i></button>
                        </div>
                    </form>
                </div>
                <ul class="social-list version-2">
                    <li><a href="https://www.facebook.com/" class="facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="https://twitter.com/" class="twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://bd.linkedin.com/" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="https://www.instagram.com/" class="instagram"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="https://vimeo.com/" class="vimeo"><i class="fa fa-vimeo"></i></a></li>
                </ul><!-- .social-list -->
                <div class="text-center">
                    <a href="#" class="btn btn-primary">Purchase Now</a>
                </div>
            </div>
        </div>
    </div>
</div>    <!-- END sidebar widget item -->    <!-- END offset cart -->

		 <?php include 'footer.php';?>
         <style type="text/css">
             .ab
                { margin-block-start: 104px;
             }
         </style>