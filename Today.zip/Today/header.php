<!-- get_header('Page Name','Title')-->
<!doctype html>
<html class="no-js" lang="en">

<!-- Mirrored from nrutpu.000webhostapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 30 Dec 2018 05:58:44 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Today Web Technology</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900%7COpen+Sans:400,700,700i" rel="stylesheet">

    <link rel="icon" type="image/png" href="favicon.html">
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="apple-touch-icon.html">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/iconfont.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/rev-settings.css">

    <!--For Plugins external css-->
    <link rel="stylesheet" href="assets/css/plugins.css" />

    <!--Theme custom css -->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--Theme Responsive css-->
    <link rel="stylesheet" href="assets/css/responsive.css" />
</head>
<body>

    <div class="header header-transparent nav-sticky">
        <!-- header section -->
        <header class="xs-header header-main">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="xs-logo-wraper">
                            <a href="index.php" class="xs-logo">
                                <img src="assets/images/logob.png" alt="" class="logo-transparent">
                                <img src="assets/images/logoa.png" alt="" class="logo-sticky">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-6">
                        <nav class="xs-menus align-to-right">
                            <div class="nav-header">
                                <a class="nav-brand" href="index.php"></a>
                                <div class="nav-toggle"></div>
                            </div>
                            <div class="nav-menus-wrapper">
                                <ul class="nav-menu align-to-right">
                                    <li><a href="index.php">HOME</a>

                                    </li>
                                    <li><a href="about.php">ABOUT</a></li>

                                    <li><a href="services.php">SERVICES</a>
                                        <ul class="nav-dropdown xs-icon-menu clearfix">
                                            <li class="single-menu-item">
                                                <a href="sms-services.php"><i class="icon icon-envelope2"></i>SMS Services</a>
                                                <ul class="nav-dropdown xs-icon-menu clearfix">
                                                    <li class="single-menu-item">
                                                        <a href="promotional-sms.php"><i class="icon icon-envelope2"></i>Promotional SMS</a>

                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="international-sms.php"><i class="icon icon-envelope2"></i>International SMS</a>

                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="transactional-sms.php"><i class="icon icon-envelope2"></i>Transactional SMS</a>

                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="voice-sms-brodcast.php"><i class="icon icon-envelope2"></i>Voice SMs Brodcast</a>

                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="smpp-Services.php"><i class="icon icon-envelope2"></i>SMPP Services</a>

                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="bulk-sms-services.php"><i class="icon icon-envelope2"></i>Bulk SMS Services</a>

                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="reseller-services.php"><i class="icon icon-envelope2"></i>Reseller Programe</a>

                                                    </li>

                                                </ul>
                                            </li>
                                            <li class="single-menu-item">
                                                <a href="websit-services.php"><i class="icon icon-dart-board"></i>Website Services</a>
                                                <ul class="nav-dropdown xs-icon-menu clearfix">
                                                    <li class="single-menu-item">
                                                        <a href="website-design.php"><i class="icon icon-dart-board"></i>Website Design</a> 
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="responsiv-website.php"><i class="icon icon-dart-board"></i>Responsiv Website</a>

                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="protals-dsevelopment.php"><i class="icon icon-dart-board"></i>Protals/ERP Development</a> 
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="cms-website.php"><i class="icon icon-dart-board"></i>CMS Website</a> 
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="e-commerercep-rotal.php"><i class="icon icon-dart-board"></i>E-Commererce Protal</a> 
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="website-maintenance.php"><i class="icon icon-dart-board"></i>Website Maintenance</a> 
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="print-media-solutions.php"><i class="icon icon-dart-board"></i>Print Media Solutions</a> 
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="print-pamphlet-distribtion.php"><i class="icon icon-dart-board"></i>Print Pamphlet Distribtion</a> 
                                                    </li>

                                                </ul>
                                            </li>
                                            <li class="single-menu-item">
                                                <a href="social-services.php"><i class="icon icon-like"></i> Social Media </a>
                                                <ul class="nav-dropdown xs-icon-menu clearfix">
                                                    <li class="single-menu-item">
                                                        <a href="facebook-promotion.php"><i class="icon icon-like"></i>Facebook Promotion</a> 
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="youtube-promotion.php"><i class="icon icon-like"></i>Youtube Promotion</a>  
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="pinterest-promotion.php"><i class="icon icon-like"></i>Pinterest Promotion</a>           </li>
                                                        <li class="single-menu-item">
                                                            <a href="sound-cloud-promotion.php"><i class="icon icon-like"></i> Sound Cloud Promotion</a>  
                                                        </li>
                                                        <li class="single-menu-item">
                                                            <a href="instagram-promotion.php"><i class="icon icon-like"></i>Instagram Promotion</a>          </li>
                                                            <li class="single-menu-item">
                                                                <a href="seo-promotion.php"><i class="icon icon-like"></i>SEO Promotion</a> 
                                                            </li>
                                                            <li class="single-menu-item">
                                                                <a href="google-adwords.php"><i class="icon icon-like"></i>Google Adwords (PPc) </a> 
                                                            </li>
                                                            <li class="single-menu-item">
                                                                <a href="bing-yahoo.php"><i class="icon icon-like"></i>Bing/Yahoo BING (PPC) </a> 
                                                            </li>

                                                        </ul>
                                                    </li>
                                                    <li class="single-menu-item">
                                                        <a href="web-hosting.php"><i class="icon icon-stats-3"></i>Web Hosting</a>
                                                        <ul class="nav-dropdown xs-icon-menu clearfix">
                                                            <li class="single-menu-item">
                                                                <a href="linux-hosting.php"><i class="icon icon-stats-3"></i>Linux Hosting</a> 
                                                            </li>
                                                            <li class="single-menu-item">
                                                                <a href="windows-hosting.php"><i class="icon icon-stats-3"></i>Windows Hosting</a>  
                                                            </li>
                                                            <li class="single-menu-item">
                                                                <a href="linux-reseller-hosting.php"><i class="icon icon-stats-3"></i>Linux Reseller Hosting</a>        </li>
                                                                <li class="single-menu-item">
                                                                    <a href="windows-reseller-hosting.php"><i class="icon icon-stats-3"></i>Windows Reseller Hosting</a>  
                                                                </li>
                                                                <li class="single-menu-item">
                                                                    <a href="vps-servers.php"><i class="icon icon-stats-3"></i>VPS Servers</a>      
                                                                </li>
                                                                <li class="single-menu-item">
                                                                    <a href="dedicated-servers.php"><i class="icon icon-stats-3"></i>Dedicated Servers</a> 
                                                                </li>


                                                            </ul>
                                                        </li>
                                                        <li class="single-menu-item">
                                                            <a href="apps-marketing.php"><i class="icon icon-stats-4"></i>APPS Marketing</a>
                                                            <ul class="nav-dropdown xs-icon-menu clearfix">
                                                                <li class="single-menu-item">
                                                                    <a href="social-media-marketing.html"><i class="icon icon-stats-4"></i>Android Apps Creation</a> 
                                                                </li>
                                                                <li class="single-menu-item">
                                                                    <a href="social-media-marketing.html"><i class="icon icon-stats-4"></i>IOS Apps Creation</a>  
                                                                </li>
                                                                <li class="single-menu-item">
                                                                    <a href="social-media-marketing.html"><i class="icon icon-stats-4"></i>Android Apps Promotion</a>        </li>
                                                                    <li class="single-menu-item">
                                                                        <a href="social-media-marketing.html"><i class="icon icon-stats-4"></i>IOS Apps Promotion</a>  
                                                                    </li>
                                                                    <li class="single-menu-item">
                                                                        <a href="social-media-marketing.html"><i class="icon icon-stats-4"></i>Apps Downloads And Installs</a>      
                                                                    </li>
                                                                    <li class="single-menu-item">
                                                                        <a href="social-media-marketing.html"><i class="icon icon-stats-4"></i>Apps Ratting And Review</a> 
                                                                    </li>
                                                                    <li class="single-menu-item">
                                                                        <a href="social-media-marketing.html"><i class="icon icon-stats-4"></i>Advertising On  Apps</a> 
                                                                    </li>
                                                                    <li class="single-menu-item">
                                                                        <a href="social-media-marketing.html"><i class="icon icon-stats-4"></i>Google Play Developer Account</a> 
                                                                    </li>
                                                                </ul>
                                                            </li>
                                                            <li class="single-menu-item">
                                                                <a href="email-services.php"><i class="icon icon-search2"></i>Email Services</a>
                                                                <ul class="nav-dropdown xs-icon-menu clearfix">
                                                                    <li class="single-menu-item">
                                                                        <a href="promotional-email.php"><i class="icon icon-search2"></i>Promotional Email</a> 
                                                                    </li>
                                                                    <li class="single-menu-item">
                                                                        <a href="dedicated-smtp-server.php"><i class="icon icon-search2"></i>Dedicated SMTP Server</a>  
                                                                    </li>
                                                                    <li class="single-menu-item">
                                                                        <a href="transactional-email.php"><i class="icon icon-search2"></i>Transactional Email</a>        </li>
                                                                        <li class="single-menu-item">
                                                                            <a href="mailer-design.php"><i class="icon icon-search2"></i>Mailer Design</a>  
                                                                        </li>

                                                                    </ul>

                                                                </li>

                                                                <li class="single-menu-item"> <a href="video-engine-marketing.php"><i class="icon icon-wallet"></i>Video Engine Marketing</a></li>

                                                                <li class="single-menu-item"><a href="ivr-services.php"><i class="icon icon-folder2"></i>IVR Services</a></li>


                                                            </ul>
                                                        </li>
                                                        <li><a href="blog.php">BLOG</a></li>
                                                        <li><a href="contact.php">CONTACT</a></li>
                                                    </ul>
                                                </div>
                                            </nav>
                                        </div>
                                        <div class="col-lg-2 col-md-6">
                                            <ul class="xs-menu-tools">


                                                <li>
                                                    <a href="#modal-popup-2" class="navsearch-button xs-modal-popup"><i class="icon icon-search"></i></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div><!-- .row END -->

                                </div><!-- .container END -->
                            </header>    <!-- End header section -->
                        </div>