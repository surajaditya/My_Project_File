<?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="inner-banner-content">
                    <h1 class="inner-banner-title">Social Media Services</h1>
                    <ul class="breadcumbs list-inline">
                        <li><a href="index.php">Home</a></li>
                        <li>Services</li>
                    </ul>
                    <span class="border-divider style-white"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- cases section -->
<section class="xs-section-padding">
    <div class="container">
        <center><h2>Social Media Services</h2></center>
        <div class="cases-grid">
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/facebook2.png" alt="">
                        <div class="hover-area">
                            <a href="facebook-promotion.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="facebook-promotion.php">Facebook Promotion</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/youtube.png" alt="">
                        <div class="hover-area">
                            <a href="youtube-promotion.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="youtube-promotion.php">Youtube Promotion</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/social-media-marketing.png" alt="social-media-marketing">
                        <div class="hover-area">
                            <a href="pinterest-promotion.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="pinterest-promotion.php">Pinterest Promotion</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/Sound-Cloud-Promotion.png" alt="Sound-Cloud-Promotion">
                        <div class="hover-area">
                            <a href="sound-cloud-promotion.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="sound-cloud-promotion.php">Sound Cloud Promotion</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/Instagram-for-Summer-Camps.png" alt="Instagram-for-Summer-Camps">
                        <div class="hover-area">
                            <a href="instagram-promotion.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="instagram-promotion.php">Instagram Promotion</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/what-is-seo.jpg" alt="what-is-seo">
                        <div class="hover-area">
                            <a href="seo-promotion.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="seo-promotion.php">SEO Promotion</a>
                        </h2>

                    </div> 
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/google-ads.png" alt="">
                        <div class="hover-area">
                            <a href="google-adwords.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="google-adwords.php">Google Adwords (PPc)</a>
                        </h2>

                    </div> 
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/How-to-Build-Your-Own-Yahoo-Bing-PPC-Campaign-AD.jpg" alt="How-to-Build-Your-Own-Yahoo-Bing-PPC-Campaign-AD">
                        <div class="hover-area">
                            <a href="bing-yahoo.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="bing-yahoo.php">Bing/Yahoo BING (PPC)</a>
                        </h2>

                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>

<!-- call to action section -->
<section class="call-to-action-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="call-to-action-content">
                    <h2>Interested To Get Our Featured Service</h2>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="btn-wraper">
                    <a href="contact.php" class="btn btn-info icon-right"><i class="icon icon-arrow-right"></i>Get Started Now</a>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'footer.php';?>
