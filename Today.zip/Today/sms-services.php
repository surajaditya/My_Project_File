<?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="inner-banner-content">
                    <h1 class="inner-banner-title">SMS Services </h1>
                    <ul class="breadcumbs list-inline">
                        <li><a href="index.php">Home</a></li>
                        <li>Services</li>
                    </ul>
                    <span class="border-divider style-white"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- cases section -->
<section class="xs-section-padding">
    <div class="container">
        <center><h2>Our SMS Services</h2></center>
        <div class="cases-grid">
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/promo_sms.jpg" alt="">
                        <div class="hover-area">
                            <a href="promotional-sms.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="promotional-sms.php">Promotional SMS</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/international.jpg" alt="">
                        <div class="hover-area">
                            <a href="international-sms.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="international-sms.php">International SMS</a>
                        </h2>

                    </div><!-- .cases-content END -->
                </div><!-- .single-cases-card END -->
            </div><!-- .cases-grid-item END -->
            <div class="cases-grid-item item1">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/tradi_sms.jpg" alt="">
                        <div class="hover-area">
                            <a href="transactional-sms.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="transactional-sms.php">Transactional SMS</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/voice_broadcasting.png" alt="">
                        <div class="hover-area">
                            <a href="voice-sms-brodcast.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="voice-sms-brodcast.php">Voice SMS Brodcast</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item2">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/sampp.jpg" alt="">
                        <div class="hover-area">
                            <a href="smpp-Services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div><!-- .card-image END -->
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="smpp-Services.php">SMPP Services</a>
                        </h2>

                    </div>
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/bulk-sms.jpg" alt="">
                        <div class="hover-area">
                            <a href="bulk-sms-services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="bulk-sms-services.php">Bulk SMS Services</a>
                        </h2>

                    </div> 
                </div>
            </div>
            <div class="cases-grid-item item1 item3">
                <div class="single-cases-card">
                    <div class="card-image">
                        <img src="assets/image/best-reseller.png" alt="">
                        <div class="hover-area">
                            <a href="reseller-services.php"><i class="icon icon-bullhorn"></i></a>
                        </div>
                    </div>
                    <div class="cases-content">
                        <h2 class="xs-title">
                            <a href="reseller-services.php">Reseller Programe </a>
                        </h2>

                    </div> 
                </div>
            </div>
            
        </div>
    </div>
</section>

<!-- call to action section -->
<section class="call-to-action-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="call-to-action-content">
                    <h2>Interested To Get Our Featured Service</h2>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="btn-wraper">
                    <a href="contact.php" class="btn btn-info icon-right"><i class="icon icon-arrow-right"></i>Get Started Now</a>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include 'footer.php';?>
