 <?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="inner-banner-content">
					<h1 class="inner-banner-title">Typography</h1>
					<ul class="breadcumbs list-inline">
						<li><a href="index.php">Home</a></li>
						<li>Typography</li>
					</ul>
					<span class="border-divider style-white"></span>
				</div>
			</div>
		</div>
	</div>
	<div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- typography section -->
<section class="xs-section-padding">
    <div class="container">
        
        <div class="typography-group">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="xs-heading text-center">
                        <h2 class="section-title"><span>03 Columns</span> Layout</h2>
                        <span class="line"></span>
                    </div>    
                </div>
            </div><!-- .row END -->            
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="demo-content text-center">
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="demo-content text-center">
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="demo-content text-center">
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    </div>
                </div>
            </div>
        </div><!-- .typography-group END -->
        <div class="typography-group">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="xs-heading text-center">
                        <h2 class="section-title"><span>04 Columns</span> Layout</h2>
                        <span class="line"></span>
                    </div>    
                </div>
            </div><!-- .row END -->            
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="demo-content text-center">
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="demo-content text-center">
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="demo-content text-center">
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="demo-content text-center">
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    </div>
                </div>
            </div>
        </div><!-- .typography-group END -->
        <div class="typography-group">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="xs-heading text-center">
                        <h2 class="section-title"><span>02 Columns</span> Layout</h2>
                        <span class="line"></span>
                    </div>    
                </div>
            </div><!-- .row END -->            
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="demo-content text-center">
                        <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="demo-content text-center">
                        <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend</p>
                    </div>
                </div>
            </div>
        </div><!-- .typography-group END -->
        <div class="typography-group">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="xs-heading text-center">
                        <h2 class="section-title"><span>Dropcaps </span>Style</h2>
                        <span class="line"></span>
                    </div>    
                </div>
            </div><!-- .row END -->            
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="demo-content">
                        <p class="dropcaps">wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart broken.serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="demo-content">
                        <p class="dropcaps style2">wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart broken.serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend</p>
                    </div>
                </div>
            </div>
        </div><!-- .typography-group END -->
        <div class="typography-group">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="xs-heading text-center">
                        <h2 class="section-title"><span>List </span>Style</h2>
                        <span class="line"></span>
                    </div>    
                </div>
            </div><!-- .row END -->            
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="demo-content">
                        <ul class="xs-list checkbox">
                            <li>Separated they live</li>
                            <li>Grove right at</li>
                            <li>The coast of the</li>
                            <li>Semantics, a large</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="demo-content">
                        <ul class="xs-list check">
                            <li>Separated they live</li>
                            <li>Grove right at</li>
                            <li>The coast of the</li>
                            <li>Semantics, a large</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="demo-content">
                        <ul class="xs-list arrow">
                            <li>Separated they live</li>
                            <li>Grove right at</li>
                            <li>The coast of the</li>
                            <li>Semantics, a large</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="demo-content">
                        <ul class="xs-list hand">
                            <li>Separated they live</li>
                            <li>Grove right at</li>
                            <li>The coast of the</li>
                            <li>Semantics, a large</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div><!-- .typography-group END -->
        <div class="typography-group">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="xs-heading text-center style4 mb-0"> <!-- .mb-0 class only for demo -->
                        <h2 class="section-title"><span>Increase</span> your client for <br> better position</h2>
                        <span class="line"></span>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right</p>
                    </div><!-- .xs-heading END -->
                </div>
            </div><!-- .row END -->    
        </div><!-- .typography-group END -->
        <div class="typography-group">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="xs-heading text-right style4 mb-0"> <!-- .mb-0 class only for demo -->
                        <h2 class="section-title"><span>Increase</span> your client for <br> better position</h2>
                        <span class="line"></span>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right</p>
                    </div><!-- .xs-heading END -->
                </div>
            </div><!-- .row END -->    
        </div><!-- .typography-group END -->
        <div class="typography-group">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="xs-heading style4 mb-0"> <!-- .mb-0 class only for demo -->
                        <h2 class="section-title"><span>Increase</span> your client for <br> better position</h2>
                        <span class="line"></span>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right</p>
                    </div><!-- .xs-heading END -->
                </div>
            </div><!-- .row END -->    
        </div><!-- .typography-group END -->
    </div><!-- .container END -->
</section><!-- end typography section -->

<!-- call to action section -->
<section class="call-to-action-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="call-to-action-content">
                    <h2>Interested To Get Our Featured Service</h2>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="btn-wraper">
                    <a href="contact.php" class="btn btn-info icon-right"><i class="icon icon-arrow-right"></i>Get Started Now</a>
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- end call to action section -->

<!-- language switcher strart -->
<?php include 'footer.php';?>