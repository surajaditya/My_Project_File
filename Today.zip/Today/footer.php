<footer class="xs-footer-section">
			<div class="container">
				<div class="footer-top-area">
					<div class="row">
						<div class="col-md-4">
							<div class="footer-logo">
								<a href="index.php">
									<img src="assets/images/logob.png" alt="">
								</a>
							</div><!-- .footer-logo END -->
						</div>
						<div class="col-md-8">
							<ul class="address-info-list list-inline">
								<li>
									<div class="address-icon">
										<img src="assets/images/pin.png" alt="">
									</div>
									<div class="address-info"><a href="https://goo.gl/maps/rXREhWm3iG82">C-40/4 Om Vihar , Dayal Sar  <br> Uttam Nagar West,New Delhi, INDIA</a></div>
								</li>
								<li>
									<div class="address-icon"><img src="assets/images/massage.png" alt=""></div>
									<div class="address-info"><a href="tel:+91-9871819682">+91-9871819682</a> <br> <a href="mailto:info@todaywebtechnology.com">info@todaywebtechnology.com</a></div>
								</li>
							</ul><!-- .address-info-list END -->
						</div>
					</div>
				</div><!-- .footer-top-area END -->
			</div>
			<div class="footer-main">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-lg-3">
							<div class="footer-widget">
								<h4 class="xs-content-title">Company</h4>
								<ul class="xs-lsit">
									<li><a href="about.php">About us</a></li>
									<li><a href="faq.php">FAQ</a></li>
									<li><a href="typography.php">Typography</a></li>
									<li><a href="services.php">Services</a></li>
									<li><a href="cant-find.php">Career</a></li>
									<li><a href="contact.php">Contact</a></li>
								</ul>
							</div><!-- .footer-widget END -->
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="footer-widget">
								<h4 class="xs-content-title">Services</h4>
								<ul class="xs-lsit">
									<li><a href="social-services.php">SOCIAL MEDIA SERVICES</a></li>
									<li><a href="websit-services.php">WEBSITE SERVICES</a></li>
									<li><a href="apps-marketing.php">APPS MARKETING</a></li>
									<li><a href="sms-services.php">SMS SERVICES</a></li>
									<li><a href="web-hosting.php">WEB HOSTING</a></li>
									<li><a href="email-services.php">EMAIL SERVICES</a></li>

								</ul>
							</div><!-- .footer-widget END -->
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="footer-widget">
								<h4 class="xs-content-title">Articles</h4>
								<ul class="articles-list">
									<li>
										<a class="entry-title" href="blog-single.html">Twice profit than before you ever</a>
										<span class="entry-meta"><i class="icon icon-clock"></i> January 14, 2018</span>
									</li>
									<li>
										<a class="entry-title" href="blog-single.html">Twice profit than before you ever</a>
										<span class="entry-meta"><i class="icon icon-clock"></i> January 14, 2018</span>
									</li>
									<li>
										<a class="entry-title" href="blog-single.html">Twice profit than before you ever</a>
										<span class="entry-meta"><i class="icon icon-clock"></i> January 14, 2018</span>
									</li>
								</ul><!-- .articles-list END -->
							</div><!-- .footer-widget END -->
						</div>
						<div class="col-md-6 col-lg-3">
							<div class="footer-widget">
								<h4 class="xs-content-title">Request a quote</h4>
								<form action="request-quote.php" class="contact-form" method="post">
									<input type="email" name="email" placeholder="Email" class="form-control">
									<textarea name="message" class="form-control" placeholder="Message" cols="30" rows="10"></textarea>
									<input type="submit" name="sub" value="Submit now" class="submit-btn">
								</form>
							</div><!-- .footer-widget END -->
						</div>
					</div>
				</div>
			</div><!-- .footer-main END -->
			<div class="partner-area-wraper">
				<div class="container">
					<div class="partner-area">
						<div class="row">
							<div class="col-md-8">
								<ul class="xs-lsit list-inline">
									<li class="title">RELATIONSHIP :</li>
									<li><img src="assets/images/partner/partner-1.png" alt=""></li>
									<li><img src="assets/images/partner/partner-2.png" alt=""></li>
									<li><img src="assets/images/partner/partner-3.png" alt=""></li>
									<li><img src="assets/images/partner/partner-4.png" alt=""></li>
								</ul>
							</div>
							<div class="col-md-4">
								<ul class="xs-list list-inline text-right">
									<li><img src="assets/images/card/visa.png" alt=""></li>
									<li><img src="assets/images/card/master-card.png" alt=""></li>
									<li><img src="assets/images/card/discover.png" alt=""></li>
									<li><img src="assets/images/card/american-express.png" alt=""></li>
								</ul>
							</div>
						</div>
					</div><!-- .partner-area END -->
				</div>
			</div><!-- partner-area-wraper. END -->
			<div class="copyright">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="copyright-text">
								<p>Copyright &copy; 2019, All Right Reserved <a href="http://todaywebtechnology.com/">TODAY WEB TECHNOLOGY</a></p>
							</div><!-- .copyright-text END -->
						</div>
						<div class="col-md-6">
							<ul class="social-list">
								<li><a href="https://www.facebook.com/binary.law.7" class="facebook"><i class="fa fa-facebook"></i></a></li>
								<li><a href="https://twitter.com/TWebtechnology" class="twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="https://bd.linkedin.com/" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="https://www.instagram.com/" class="instagram"><i class="fa fa-instagram"></i></a></li>
								<li><a href="https://plus.google.com/discover" class="googlePlus"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div><!-- .copyright END -->
		</footer>
		<!-- footer section end -->	
		<!-- js file start -->
		<script src="assets/js/jquery-3.2.1.min.js"></script>
		<script src="assets/js/plugins.js"></script>
		<script src="assets/js/Popper.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/jquery.magnific-popup.min.js"></script>
		<script src="assets/js/owl.carousel.min.js"></script>
		<script src="assets/js/jquery.ajaxchimp.min.js"></script>
		<script src="assets/js/jquery.waypoints.min.js"></script>
		<script src="assets/js/isotope.pkgd.min.js"></script>
		<script src="https://maps.googleapis.com/maps/api/js?v=3&amp;key=AIzaSyCy7becgYuLwns3uumNm6WdBYkBpLfy44k"></script>
		<script src="assets/js/scrollax.js"></script>
		<script src="assets/js/jquery.themepunch.revolution.min.js"></script>
		<script src="assets/js/jquery.themepunch.tools.min.js"></script>
		<script src="assets/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script src="assets/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script src="assets/js/extensions/revolution.extension.navigation.min.js"></script>
        <script src="assets/js/extensions/revolution.extension.parallax.min.js"></script>
		<script src="assets/js/jquery.easypiechart.min.js"></script>
		<script src="assets/js/delighters.js"></script>
		<script src="assets/js/main.js"></script>		<!-- End js file -->
	 </body>

<!-- Mirrored from nrutpu.000webhostapp.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 30 Dec 2018 06:04:55 GMT -->
</html>