<?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="inner-banner-content">
					<h1 class="inner-banner-title">Frequently Asked Questions</h1>
					<ul class="breadcumbs list-inline">
						<li><a href="index.php">Home</a></li>
						<li>FAQ</li>
					</ul>
					<span class="border-divider style-white"></span>
				</div>
			</div>
		</div>
	</div>
	<div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- faq accordion strart -->
<div class="faq-accordion-area xs-section-padding pb-0" data-scrollax-parent="true">
    <div class="container">
        <div class="faq-accordion-group">
            <div class="row">
                <div class="col-md-6 align-self-center">
                    <div class="accordion-wraper">
                        <!-- faq accordion strart -->
                        <div class="accordion faqAccordion" id="faqAccordion">
  <div class="card">
    <div class="card-header" id="headingOne">
      <a class="btn-link" href="#" data-toggle="collapse" data-target="#collapNrutpune" aria-expanded="true" aria-controls="collapNrutpune">
          How to Purchase Extend Licence of this Product?
      </a>
    </div>
    <div id="collapNrutpune" class="collapse show" aria-labelledby="headingOne" data-parent="#faqAccordion">
      <div class="card-body">
        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast</p>
      </div>
    </div>
  </div><!-- question one -->

  <div class="card">
    <div class="card-header" id="headingTwo">
      <a class="btn-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        How browsing and membership works
      </a>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#faqAccordion">
      <div class="card-body">
        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast</p>
      </div>
    </div>
  </div><!-- question two -->

  <div class="card">
    <div class="card-header" id="headingThree">
      <a class="btn-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        How to Manage your Own Dashboard?
      </a>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#faqAccordion">
      <div class="card-body">
        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast</p>
      </div>
    </div>
  </div><!-- question three -->
</div>                        <!-- end faq accordion -->
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="faq-img-wraper text-center">
                        <img src="assets/images/faq-ladies-vector.png" alt="">
                    </div>
                </div>
            </div><!-- .row END -->
        </div><!-- .faq-accordion-group END -->
    </div><!-- .container END -->
    <div class="doodle-parallax">
        <img src="assets/images/doodle/doodle-2.png" data-scrollax="properties: { translateY: '-100%' }" class="single-doodle one" alt="">
        <img src="assets/images/doodle/doodle-1.png" data-scrollax="properties: { translateY: '100%' }" class="single-doodle two" alt="">
        <img src="assets/images/doodle/doodle-1.png" data-scrollax="properties: { translateY: '-100%' }" class="single-doodle three" alt="">
    </div>
</div><!-- end faq accordion -->

<!-- faq question strart -->
<div class="faq-question-area xs-section-padding pb-0" data-scrollax-parent="true">
    <div class="container">
        <div class="faq-question-wraper">
            <div class="row xs-faq-group">
                <div class="col-md-6">
                    <div class="xs-single-faq">
                        <h2 class="faq-question">What is marketpress.com?</h2>
                        <p>marketpress is the leading Business to Consumer e-commerce site. It is an online retail that enables anyone from anywhere in Bangladesh and from around the world to purchase different items/products through online.</p>
                    </div><!-- .xs-single-faq END -->
                    <div class="xs-single-faq">
                        <h2 class="faq-question">I need to sign up before buying any Offer/Product?</h2>
                        <p>marketpress is the leading Business to Consumer e-commerce site. It is an online retail that enables anyone from anywhere in Bangladesh and from around the world to purchase different items/products through online.</p>
                    </div><!-- .xs-single-faq END -->
                    <div class="xs-single-faq">
                        <h2 class="faq-question">What type of products do you sell online?</h2>
                        <p>marketpress is the leading Business to Consumer e-commerce site. It is an online retail that enables anyone from anywhere in Bangladesh and from around the world to purchase different items/products through online.</p>
                    </div><!-- .xs-single-faq END -->
                    <div class="xs-single-faq">
                        <h2 class="faq-question">Is my info safe?</h2>
                        <p>marketpress is the leading Business to Consumer e-commerce site. It is an online retail that enables anyone from anywhere in Bangladesh and from around the world to purchase different items/products through online.</p>
                    </div><!-- .xs-single-faq END -->
                </div>
                <div class="col-md-6">
                    <div class="xs-single-faq">
                        <h2 class="faq-question">Why my card payment is failing?</h2>
                        <p>marketpress is the leading Business to Consumer e-commerce site. It is an online retail that enables anyone from anywhere in Bangladesh and from around the world to purchase different items/products through online.</p>
                    </div><!-- .xs-single-faq END -->
                    <div class="xs-single-faq">
                        <h2 class="faq-question">How do I create an marketpress.com account?</h2>
                        <p>marketpress is the leading Business to Consumer e-commerce site. It is an online retail that enables anyone from anywhere in Bangladesh and from around the world to purchase different items/products through online.</p>
                    </div><!-- .xs-single-faq END -->
                    <div class="xs-single-faq">
                        <h2 class="faq-question">Am I billed as soon as I join marketpress.com?</h2>
                        <p>marketpress is the leading Business to Consumer e-commerce site. It is an online retail that enables anyone from anywhere in Bangladesh and from around the world to purchase different items/products through online.</p>
                    </div><!-- .xs-single-faq END -->
                    <div class="xs-single-faq">
                        <h2 class="faq-question">Why should I subscribe newsletter?</h2>
                        <p>marketpress is the leading Business to Consumer e-commerce site. It is an online retail that enables anyone from anywhere in Bangladesh and from around the world to purchase different items/products through online.</p>
                    </div><!-- .xs-single-faq END -->
                </div>
            </div><!-- .faq-question-wraperrow END -->
        </div><!-- . END -->
    </div><!-- .container END -->
    <div class="doodle-parallax">
        <img src="assets/images/doodle/2.html" data-scrollax="properties: { translateY: '-100%' }" class="single-doodle one" alt="">
    </div>
</div><!-- end faq question -->

<!-- get support section -->
<section class="xs-section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="hiring-image">
                    <img src="assets/images/man-with-phone.jpg" alt="">
                </div>
            </div>
            <div class="col-md-7">
                <div class="hiring-content getSupport-content">
                    <h2><span>Don’t get any?</span> Our support team will assist you</h2>
                    <a href="tel:+91%9871819682" class="btn btn-primary style2 icon-left"><i class="icon icon-phone3"></i> +91-9871819682</a>
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- end get support section -->

<!-- language switcher strart -->
<?php include 'footer.php';?>