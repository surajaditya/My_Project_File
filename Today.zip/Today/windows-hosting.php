 <?php include 'header.php';?>
<!-- inner banenr start -->
<!--breadcumb start here-->
<section class="inner-banner-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="inner-banner-content">
                    <h1 class="inner-banner-title">Web Hosting</h1>
                    <ul class="breadcumbs list-inline">
                        <li><a href="index.php">Home</a></li>
                        <li>Details</li>
                    </ul>
                    <span class="border-divider style-white"></span>
                </div>
            </div>
        </div>
    </div>
    <div class="banner-image" style="background-image:url('assets/images/backgrounds/background-1.jpg')"></div>
</section>
<!--breadcumb end here--><!-- inner banenr end -->

<!-- service info section start -->
<section class="xs-section-padding service-info-section" data-scrollax-parent="true">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="xs-heading text-center">
                    <h2 class="section-title">Increase your client for <span>better position</span> of Business</h2>
                    <span class="line"></span>
                </div><!-- .xs-heading END -->
            </div>
        </div><!-- .row END -->
        <div class="row service-info-wraper">
            <div class="col-lg-6">
                <div class="service-info-summary">
                    <h3>Window Hosting </h3>
                    <p>Windows hosting uses Windows as the servers' operating system and offers Windows-specific technologies such as ASP, .NET, Microsoft Access and Microsoft SQL server (MSSQL).<br>Most web hosting service providers offer two kinds of hosting: Linux hosting and Windows hosting. In general, Linux hosting refers to shared hosting, the most popular hosting service in the industry. In fact, most of the websites are now hosted using Linux hosting due to its affordable price and flexibility. Linux hosting is compatible with PHP and MySQL, which supports scripts such as WordPress, Zen Cart, and phpBB.<br>In this competetive world every businesses online and individuals need to invest a lot of time as well energy into managing and maintaining dynamic websites for their businesses that are truly visually effective and can also attract more users.<br>Website owners looking for a simple and more effective way to deal with their content are more and more turning to Windows hosting solution. The availability of ASP (Active Server Pages) from Microsoft’s in Windows web hosting solutions provides for dynamically created web pages that can help give your business websites the best possible presentation and performance level.<br>Active server pages (ASP) is a most powerful and highly flexible technology that can provide your website users with a variety of interactive page choices and services that surpasses the benchmark. </p>
                     
              </div>
            </div>
            <div class="col-lg-6">
                <div class="service-info-img ab">
                    <img src="assets/image/today-windo-hosting.jpg" data-scrollax="properties: { translateY: '-20%' }" alt="today-windo-hosting">
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- end service info section -->

<!-- service info block section start -->
<section class="xs-section-padding gray-bg service-info-block-area">
    <div class="container">
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="xs-heading text-center">
                    <h2 class="section-title">Show appreciation for the teams behind your favorite services. Write your message, tag the recipients, and leave the pre-filled hashtags for a chance to be featured in the Today web technology Hall of Fame</h2>
                </div><!-- .xs-heading END -->
            </div>
        </div><!-- .row END -->
        <div class="row service-block-group">
            <div class="col-md-6 col-lg-4">
                <div class="service-info-block text-center">
                    <div class="info-block-header">
                        <img src="assets/images/service-info-icon-1.png" alt="">
                    </div>
                    <h3 class="service-info-title">Link Building</h3>
                    <p>Building links is one of the many tactics used in search engine optimization (SEO) because links are a signal to Google that your site is a quality resource worthy of citation. Therefore, sites with more backlinks tend to earn higher rankings. There's a right way and a wrong way, however, to build links to your site.</p>
                </div><!-- .service-info-block END -->
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="service-info-block text-center">
                    <div class="info-block-header">
                        <img src="assets/images/service-info-icon-2.png" alt="">
                    </div>
                    <h3 class="service-info-title">Monthly TODAY WEB TECHNOLOGY Task</h3>
                    <p>An intuitive dashboard lets you segment your site by traffic source, conversion trends, device and behavior.Quickly understand how ALL of your traffic impacts conversions and engagement.</p>
                </div><!-- .service-info-block END -->
            </div>
            <div class="col-md-6 col-lg-4">
                <div class="service-info-block text-center">
                    <div class="info-block-header">
                        <img src="assets/images/service-info-icon-3.png" alt="">
                    </div>
                    <h3 class="service-info-title">On Page TODAY WEB TECHNOLOGY</h3>
                    <p>A web page or webpage is a document commonly written in HTML (Hypertext Markup Language) that is accessible through the Internet or other networks using an Internet browser. A web page is accessed by entering a URL address and may contain text, graphics, and hyperlinks to other web pages and files.</p>
                </div><!-- .service-info-block END -->
            </div>
        </div><!-- .row .service-block-group END -->
        <div class="row">
            <div class="col-md-12">
                <div class="service-img text-center">
                    <img src="assets/images/service-img-2.png" alt="">
                </div>
                <div class="btn-wraper text-center">
                    <a href="contact.php" class="btn btn-primary">Get a Quote</a>
                    <a href="contact.php" class="btn btn-outline-primary">Try Free</a>
                </div>
            </div>
        </div>
    </div><!-- .container END -->
</section><!-- end service info block section -->

<!-- our security section start -->
<section class="xs-section-padding our-security-section waypoint-tigger" data-scrollax-parent="true">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="service-summary-img">
                    <img src="assets/images/service-summary-1.png" data-scrollax="properties: { translateY: '-20%' }" alt="">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="service-summary-text">
                    <div class="xs-heading">
                        <h2 class="section-title">Security <span>Firewall</span></h2>
                        <span class="line"></span>
                    </div><!-- .xs-heading END -->        
                    <p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence in this spot, which was created for the bliss of souls like mine. I am so happy, my dear friend, so absorbed</p>
                    <div class="piechats-wraper clearfix">
                        <div class="single-piechart">
                            <div class="chart" data-percent="76">
                                <div class="chart-content"> 
                                    <p>Achieved</p>
                                </div>
                            </div>
                        </div><!-- .single-piechart END -->
                        <div class="single-piechart">
                            <div class="chart" data-percent="93">
                                <div class="chart-content"> 
                                    <p>Loaded</p>
                                </div>
                            </div>
                        </div><!-- .single-piechart END -->
                        <div class="single-piechart">
                            <div class="chart" data-percent="85">
                                <div class="chart-content"> 
                                    <p>Done</p>  
                                </div>
                            </div>
                        </div><!-- .single-piechart END -->
                    </div>    
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- end our security section -->

<!-- boosting section start -->
<section class="xs-section-padding boosting-section waypoint-tigger" data-scrollax-parent="true">
    <div class="container">
        <div class="row service-info-wraper">
            <div class="col-lg-6">
                <div class="service-summary-text service-summary-2">
                    <div class="xs-heading">
                        <h2 class="section-title">Turbo <span>Boosting</span></h2>
                        <span class="line"></span>
                    </div><!-- .xs-heading END -->        
                    <div class="boosting-lists">
                        <div class="boosting-list">
                            <span class="count-number"></span>
                            <p>Intel Turbo Boost is Intel's trade name for a feature that automatically raises certain of its processors' operating frequency, and thus performance, when demanding tasks are running. ... The design concept behind Turbo Boost is commonly referred to as "dynamic overclocking"</p>
                        </div><!-- .boosting-list END -->
                        <div class="boosting-list">
                            <span class="count-number"></span>
                            <p>I throw myself down among the tall grass by the trickling stream; and, as I lie close to the earth, a <a href="#">thousand unknown</a> plants are noticed by me: when I hear</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="service-summary-img">
                    <img src="assets/images/service-summary-2.png" data-scrollax="properties: { translateY: '20%' }" alt="">
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section>
<!-- end boosting section -->


<!-- case study slider -->
<section class="xs-section-padding gray-bg" id="cases">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mx-auto">
                    <div class="xs-heading text-center">
                        <h2 class="section-subtitle">RELETED SERVICES</h2>
                        <h3 class="section-title ">Our Case Studies</h3>
                    </div><!-- .xs-heading END -->
                </div>
            </div><!-- .row END -->
            <div class="case-study-slider owl-carousel">
                <div class="case-study-slider-item">
                    <div class="single-case-studies text-center wow fadeInUp">
                        <div class="image">
                            <img src="assets/image/linux.jpg" alt="linux-hosting">
                        </div>
                        <div class="case-body">
                            <h4 class="small"><a href="linux-hosting.php">Linux Hosting</a></h4>
                            <p>Web Hosting</p>
                        </div>
                    </div><!-- .single-case-studies END -->
                </div>
                
                <div class="case-study-slider-item">
                    <div class="single-case-studies text-center wow fadeInUp" data-wow-duration="1.4s">
                        <div class="image">
                            <img src="assets/image/Linux-Reseller-Hosting.jpg" alt="">
                        </div>
                        <div class="case-body">

                            <h4><a href="linux-reseller-hosting.php">Linux Reseller Hosting</a></h4>
                            <p>Web Hosting </p>
                        </div>
                    </div><!-- .single-case-studies END -->
                </div>
                <div class="case-study-slider-item">
                    <div class="single-case-studies text-center wow fadeInUp">
                        <div class="image">
                            <img src="assets/image/windows-hosting.jpg" alt="windows-hosting">
                        </div>
                        <div class="case-body">
                            <h4 class="small"><a href="windows-reseller-hosting.php">Windows Reseller Hosting</a></h4>
                             <p>Web Hosting </p>
                        </div>
                    </div><!-- .single-case-studies END -->
                </div>
                <div class="case-study-slider-item">
                    <div class="single-case-studies text-center wow fadeInUp" data-wow-duration="1.2s">
                        <div class="image">
                            <img src="assets/image/best-vps-hosting-providers.jpg" alt="best-vps-hosting-providers">
                        </div>
                        <div class="case-body">
                            <h4 class="small"><a href="vps-servers.php">VPS Servers</a></h4>

                            <p>Web Hosting </p>
                        </div>
                    </div><!-- .single-case-studies END -->
                </div>
                <div class="case-study-slider-item">
                    <div class="single-case-studies text-center wow fadeInUp" data-wow-duration="1.4s">
                        <div class="image">
                            <img src="assets/image/dedicated-server.png" alt="dedicated-server">
                        </div>
                        <div class="case-body">
                            <h4 class="small"><a href="dedicated-servers.php">Dedicated Servers</a></h4>
                            <p>Web Hosting </p>
                        </div>
                    </div><!-- .single-case-studies END -->
                </div>
 
            </div><!-- .row END -->
        </div><!-- .container END -->
</section>
<!-- END case study slider -->


 

<!-- call to action section -->
<section class="call-to-action-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="call-to-action-content">
                    <h2>Interested To Get Our Featured Service</h2>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="btn-wraper">
                    <a href="contact.php" class="btn btn-info icon-right"><i class="icon icon-arrow-right"></i>Get Started Now</a>
                </div>
            </div>
        </div><!-- .row END -->
    </div><!-- .container END -->
</section><!-- end call to action section -->

<!-- language switcher strart -->
 <?php include 'footer.php';?>
  <style type="text/css">
     .ab{
    margin-block-start: 139px;

     }
 </style>