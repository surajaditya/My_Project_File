<?php 
 session_start()

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body bgcolor="#008B8B" text="">
<a href="Index.php" align="bottom">Register New Students</a>
	

<center>
	<form  method="post" action="show.php">
		<table border="7">
		<tr>
		<th colspan="3">User Login</th>
		</tr>		
		<tr>
		<td>Email.Id</td>
		<td>:-</td>	
		<td><input type="email" name="email" placeholder="Email ID" required/></input></td>
	    </tr>
	    <tr>
	    <td>Password</td>
	    <td>:-</td> 	
		<td><input type="password" name="pass" placeholder="Password" required/></td>
	    </tr>
        <tr>
        <td>Click On </td>
        <td>:-</td>	
		<td><input type="submit" name="login" value="Login"></td>
	    </tr>
	</table>
	</form>
</center>

</body>
</html>


<?php
include 'Config.php';

if(isset($_POST['login']))
{
$email = $_SESSION['email']=$_POST['email'];
$pass = $_POST['pass'];

$query = "select * from student where email ='$email' AND password ='$pass'";

$query_run = mysqli_query($con,$query); 
	
		if(mysqli_num_rows($query_run)>0){
		
			echo "<script> window.open('show.php?logged=Logged In Scuccessfully....?','_self')</script>";
		}
		else{
			echo "<script> window.open('Login.php?errored=Invalid User Name OR Password....?','_self')</script>";
		}
	}

?>
